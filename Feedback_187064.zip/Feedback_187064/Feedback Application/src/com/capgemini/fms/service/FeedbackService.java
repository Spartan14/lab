package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.ExceptionClass.AlreadyGiveFeedback;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.dao.FeedbackDAO;

public class FeedbackService implements IFeedbackService
{	Feedback fdback; 
	FeedbackDAO FbDao=new FeedbackDAO();
	Validation v=new Validation();
//method to store feedback in hash map
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws AlreadyGiveFeedback {
		fdback=new Feedback(name,subject,rating);
		String sub=v.checkSubjectName(subject);
		int rat=v.checkRating(rating);
		Map<String,Integer> map=FbDao.addFeedbackDetails(name, rat, sub);
		return map;
	}
	// method to fetch detail from hash map
	public Map<String, Integer> getFeedbackReport() {
		Map<String, Integer> m=FbDao.getFeedbackReport();
		return m;
	}

}
