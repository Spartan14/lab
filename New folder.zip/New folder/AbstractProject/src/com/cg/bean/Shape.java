package com.cg.bean;

public abstract class Shape {
	protected final double PI=3.14;
	public void showPI()
	{
		System.out.println("PI is : "+PI);
		
	}

	public abstract void area();
	//no method body
}
