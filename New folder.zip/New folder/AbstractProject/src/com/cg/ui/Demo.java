package com.cg.ui;
import com.cg.bean.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Shape s=new Shape();//error//Abstract class can not be instantiated
		Shape s=new Circle(15.25);
		s.area();//circle area
		s.showPI();
		 s=new Rectangle(15,12);
			s.area();
	}

}
