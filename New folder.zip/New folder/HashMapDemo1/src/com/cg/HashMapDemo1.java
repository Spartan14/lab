package com.cg;
import java.util.*;
 class Key {
	int index;
	String name;
	Key(int index,String name)
	{
		this.index=index;
		this.name=name;
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 5;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return true;
	}
	}
	class HashMapDemo1{
		public static void main(String[] args) {
			Map<Key,String>hm=new HashMap<Key,String>();
			hm.put(new Key(1,"NY"),"New Yorkn City");
			hm.put(new Key(2,"ND"),"New Delhi");
			hm.put(new Key(3,"NW"),"Newark");
			hm.put(new Key(4,"NP"),"Newport ");
			
			System.out.println("Size of the map is\t:\t"+hm.size());
			Set set=hm.entrySet();
			Iterator i=set.iterator();
			while(i.hasNext()) {
				Map.Entry me=(Map.Entry)i.next();
				System.out.println(me.getKey()+"\t\t\t:\t"+me.getValue());
			}
			System.out.println("After iteration size of map is\t:\t"+hm.size());
			
		}
	}

