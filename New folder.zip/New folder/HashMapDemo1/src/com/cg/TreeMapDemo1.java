package com.cg;
import java.util.*;
public class TreeMapDemo1 {
	public static void main(String[] args) {
		TreeMap<Integer,String>treeMap=new TreeMap<Integer,String>();
		
		treeMap.put(12,"Ram");
		treeMap.put(343,"Sham");
		treeMap.put(64,"Krish");
		treeMap.put(323,"Ganesh");
		treeMap.put(74,"Balu");
		treeMap.put(37,"Sony");
		treeMap.put(11,"Deeksha");
		treeMap.put(73,"Arjun");
		
		System.out.println("Contents of treemap\t:");
		System.out.println(treeMap);
		
		SortedMap<Integer,String>smap=treeMap.subMap(20,100);
		System.out.println(smap);
		
		smap.put(30,"Vishnu");
		System.out.println("After adding 30,Vishnu\t:");
		System.out.println(treeMap);
		System.out.println(smap);
		
		treeMap.remove(73);
		System.out.println("After remove 73,Arjun\t:");
		System.out.println(treeMap);
		System.out.println(smap);
		
		Collection<String>c=treeMap.values();
		List<String>l=new ArrayList<>(c);
		System.out.println(l);
		Collections.sort(l);
		System.out.println(l);
	}

}
