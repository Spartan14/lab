package cg.bean;

import com.cg.exception.InsufficientBalanceException;

public class Savings extends Account{
	private double interest;
	public Savings() {
		// TODO Auto-generated constructor stub
	}
	
	public double getInterest() {
		return interest;
	}



	public void setInterest(double interest) {
		this.interest = interest;
	}

	public Savings(String name, int accno, double balance, double interest) {
		super(name,accno,balance);
		this.interest = interest;
	}

	@Override
	public double withdraw(double amount)throws InsufficientBalanceException {
		// TODO Auto-generated method stub
	double currentBalance=super.getBalance();
	currentBalance=currentBalance-amount;
	if(currentBalance<1000)
	{
		throw new RuntimeException(" salary should be morethan 3000");//unchecked exception
	}
	super.setBalance(currentBalance);
	return super.getBalance();
	}

	@Override
	public double deposite(double amount) {
		// TODO Auto-generated method stub
		double currentBalance=super.getBalance();
		currentBalance=currentBalance+amount;
		super.setBalance(currentBalance);
		return super.getBalance();
	}


}
