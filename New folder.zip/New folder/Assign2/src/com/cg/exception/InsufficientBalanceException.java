package com.cg.exception;

public class InsufficientBalanceException extends Exception{
public InsufficientBalanceException() {
	
}
public InsufficientBalanceException(String message) {

super(message);
}
public String toString()
{
return "cg.Exception.InsufficientBalanceException" +super.getMessage();	
}
}
