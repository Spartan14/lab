package com.cg;

public class TransactionRunnable5 implements Runnable{
	int bal=1000;
	boolean valueSet=false;
	
	@Override
	public void run() {
		
		String option=Thread.currentThread().getName();
		for(int i=1;i<=10;i++)
		{
			if(option.equals("Sham"))
			deposite(1000);
			
			if(option.equals("Ram"))
				printbalance();
		}
		
	}

	public synchronized void deposite(int amount)
	
	{
			if(!valueSet)//if(valueSet==false)
			{
				try{
					wait();
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			else
			{
			
			System.out.println("Thread\t:\t"+Thread.currentThread().getName());
			System.out.println("Balance is\t:\t"+bal);
			System.out.println("Thread start\t--\t"+Thread.currentThread().getName());
			System.out.println("Before deposite\t:\t"+bal);
			bal=bal+amount;
			System.out.println("After deposite\t:\t"+bal);
			System.out.println("Thread ended\t"+Thread.currentThread().getName());
			valueSet=false;
			notify();
			}
	}
	public synchronized void printbalance()
	{
		if(valueSet)//if(valueSet==true)
		{
			try{
				wait();
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
		
		System.out.println("Thread\t:\t"+Thread.currentThread().getName());
		System.out.println("Balance is\t:\t"+bal);
		valueSet=true;
		notify();
		}
		
	}
}
