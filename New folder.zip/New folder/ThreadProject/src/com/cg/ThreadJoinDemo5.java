package com.cg;

public class ThreadJoinDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TransactionRunnable5 m=new TransactionRunnable5();
		Thread producer=new Thread(m,"Sham");
		Thread consumer=new Thread(m,"Ram");
		
		producer.start();
		consumer.start();
		
		
		try
		{
			producer.join();
			consumer.join();
			
		}
		catch(InterruptedException exp) {
			System.err.println(exp.getMessage());
		}
		System.out.println("All threads are dead,exiting main thread");

	}

}

