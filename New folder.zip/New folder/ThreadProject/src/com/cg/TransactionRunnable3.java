package com.cg;

public class TransactionRunnable3 implements Runnable{
	int bal=1000;
	@Override
	public void run() {
		
		synchronized (this) {

		deposite(1000);
		}
		
	}

	public void deposite(int amount)
	{
		System.out.println("Thread start\t--\t"+Thread.currentThread().getName());
		System.out.println("Before deposite\t:\t"+bal);
		bal=bal+amount;
		System.out.println("After deposite\t:\t"+bal);
		System.out.println("Thread ended\t"+Thread.currentThread().getName());
	}
	public void printbalance()
	{
		System.out.println("Balance is\t:\t"+bal);
	}
}
