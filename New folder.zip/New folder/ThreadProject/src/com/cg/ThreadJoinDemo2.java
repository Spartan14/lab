package com.cg;

public class ThreadJoinDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TransactionRunnable2 m=new TransactionRunnable2();
		Thread thread1=new Thread(m,"Sham");
		Thread thread2=new Thread(m,"Ram");
		Thread thread3=new Thread(m,"Krish");
		
		thread1.start();
		thread2.start();
		thread3.start();
		
		try
		{
			thread1.join();
			thread2.join();
			thread3.join();
		}
		catch(InterruptedException exp) {
			System.err.println(exp.getMessage());
		}
		System.out.println("All threads are dead,exiting main thread");

	}

}
