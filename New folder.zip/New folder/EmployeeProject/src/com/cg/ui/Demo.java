package com.cg.ui;

import com.cg.bean.Employee;


public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee(100,"BALU",30000.00);
		e.printDetails();

	}

}
