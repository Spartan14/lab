package com.cg.bean;

public class Account {
	private int Accno;
	private String Custname;
	private double Balance;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(int accno, String custname, double balance) {
		super();
		Accno = accno;
		Custname = custname;
		Balance = balance;
	}
	public int getAccno() {
		return Accno;
	}
	public void setAccno(int accno) {
		Accno = accno;
	}
	public String getCustname() {
		return Custname;
	}
	public void setCustname(String custname) {
		Custname = custname;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public void printDetails()
	{
		System.out.println("Accno is :"+Accno+"\ncustname :"+Custname+"\nbalance :"+Balance);
		
	}
}
