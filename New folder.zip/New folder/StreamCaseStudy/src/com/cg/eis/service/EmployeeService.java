package com.cg.eis.service;

import java.text.Collator;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.cg.eis.bean.Employee;

public class EmployeeService {
	Employee e1=new Employee();
	public double getSumOfSalary(List<Employee> elist) {
		double sum=elist.stream().map(elist1->elist1.getSalary()).collect(Collectors.summingDouble(sal->sal));
		return sum;
	}
	public List<Employee>getEmployeeWithoutDept(List<Employee>elist)
	{
		List<Employee> el1=elist.stream().filter(e->e.getDep()==null).collect(Collectors.toList());
		return el1;
	}
	//List employee name,salary and salary increased by 15%
	public List<String> getSalInc(List<Employee> elist)
	{
		List<String>el3=elist.stream().map(e->e.getFirstName()+""+e.getLastName()+"\t"+e.getSalary()
		+""+(e.getSalary()*0.15)).collect(Collectors.toList());
		return el3;
	}
	//Find employee who didn't report to anyone (Hint: Employees without manager)
	public List<Employee>didnotHaveManager(List<Employee> elist){
		List<Employee> el2 = elist.stream().filter(e->e.getManagerId()==null).collect(Collectors.toList());
		return el2;
	}
	public List<Employee> sortName(List<Employee> elist)
	{
		Comparator<Employee> firstNameComparator=(e1,e2)->e1.getFirstName().compareTo(e2.getFirstName());
		List<Employee> el4=elist.stream().sorted(firstNameComparator).collect(Collectors.toList());
		return el4;
	}
	public List<Employee> sortEmpId(List<Employee>elist)
	{
		Comparator<Employee>empIdComparator=(e1,e2)->e1.getEmployeeId().compareTo(e2.getEmployeeId());
		List<Employee> el4=elist.stream().sorted(empIdComparator).collect(Collectors.toList());
		return el4;
	}
	public List<Employee>sortDeptId(List<Employee>elist)
	{
		Comparator<Employee>deptIdComparator=(e1,e2)->e1.getDep().getDepartmentId().compareTo(e2.getDep().getDepartmentId());
		List<Employee>el4=elist.stream().filter(e->e.getDep()!=null).sorted(deptIdComparator).collect(Collectors.toList());
		List<Employee>el5=elist.stream().filter(e->e.getDep()==null).collect(Collectors.toList());
		return el4;
	}

}
