package com.cg.eis.pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.eis.bean.Department;
import com.cg.eis.bean.Employee;

public class EmployeeRepository {
	
	public static List<Department> getDepartments()
	{
		List<Department>dlist=new ArrayList<>();
		dlist.add(new Department(10,"IT",100));
		dlist.add(new Department(20,"Sales",101));
		dlist.add(new Department(30,"Marketing",102));
		dlist.add(new Department(40,"HR",103));
		return dlist;
		
	}
	public static List<Employee> getEmployees()
	{
		List<Employee>elist=new ArrayList<>();
		elist.add(new Employee(100,"AB","Devilliars","abd@cg.com","9645825465",LocalDate.of(2012, 6, 14),"President",50000.00,null,new Department(10,"IT",100)));
		elist.add(new Employee(101,"MS","Dhoni","msd@cg.com","9321652654",LocalDate.of(2015, 8, 3),"Sales_Mgr",47000.00,100,new Department(20,"Sales",101)));
		elist.add(new Employee(102,"Suresh","Raina","suresh@cg.com","9646257819",LocalDate.of(2011, 3, 22),"Marketing",16000.00,100,new Department(30,"Marketing",102)));
		elist.add(new Employee(103,"Shane","Watson","shane@cg.com","9640425036",LocalDate.of(2015, 8, 3),"Sales_Mgr",47000.00,100,null));
		elist.add(new Employee(104,"Virat","Kohli","virat@cg.com","9600825775",LocalDate.of(2015, 8, 3),"Sales_Mgr",47000.00,100,null));
		elist.add(new Employee(105,"Venky","Balu","balu@cg.com","9493434936",LocalDate.of(2015, 8, 3),"Sales_mgr",45000.00,null,new Department(20,"Sales",101)));
		elist.add(new Employee(106,"Deeksha","Sony","sony@cg.com","9398430432",LocalDate.of(2015, 8, 3),"sales_mgr",45000.00,100,new Department(20,"Sales",101)));
		return elist;
	}

}
