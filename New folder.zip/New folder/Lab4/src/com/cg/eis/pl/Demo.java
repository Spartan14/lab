package com.cg.eis.pl;
import com.cg.eis.bean.*;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number");
		int a=sc.nextInt();
		Operators op=new Operators();
		System.out.println(op.sumofcubes(a));
		

	}

}
