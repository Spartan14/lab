package com.cg.eis.bean;

public class Operators {
	public int sumofcubes(int n)
	{int sum=0;
		while(n>0)
		{
			int a=n%10;
			int b=a*a*a;
			sum=sum+b;
			n=n/10;
		}
		return sum;
	}

}
