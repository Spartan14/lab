package com.cg.eis.pl;
import com.cg.eis.bean.Exercise5;
import com.cg.eis.exception.InvalidAgeException;
public class Demo5 {

	public static void main(String[] args) throws InvalidAgeException{
		// TODO Auto-generated method stub
		Exercise5 p=new Exercise5();
		p.Details("BALU",25);

	}

}
