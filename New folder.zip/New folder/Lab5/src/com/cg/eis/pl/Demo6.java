package com.cg.eis.pl;

import com.cg.eis.bean.Exercise6;
import com.cg.eis.exception.SalaryException;

public class Demo6 {

	public static void main(String[] args) throws SalaryException {
		// TODO Auto-generated method stub
		Exercise6 e=new Exercise6();
		e.chesksal(2200);
		
	}

}
