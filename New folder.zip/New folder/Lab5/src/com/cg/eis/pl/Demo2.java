package com.cg.eis.pl;
import com.cg.eis.bean.*;
import java.util.*;
public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the max range to fibonacci series : ");
		int n=sc.nextInt();
		Exercise2 l2=new Exercise2();
		System.out.println("==========\n");
		l2.fib(n);
		System.out.println("==========\n");
		System.out.println("Using Recursive Function : ");
		for(int i=0;i<n;i++)
		{
			System.out.println(l2.recursiveFib(i)+" ");
		}
		System.out.println("\n=============\n");

	}

}
