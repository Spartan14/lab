package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.*;
public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the range to print Prime numbers : ");
		int n=sc.nextInt();
		Exercise3 l3=new Exercise3();
		l3.getPrimes(n);

	}

}
