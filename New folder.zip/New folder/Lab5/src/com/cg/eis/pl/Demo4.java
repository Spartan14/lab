package com.cg.eis.pl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.eis.bean.Ecercise4;
import com.cg.eis.exception.EmptyException;
public class Demo4 {

	public static void main(String[] args) throws IOException,EmptyException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter first name");
		String fName=br.readLine();
		
		System.out.println("Enter last name");
		String lName=br.readLine();
		
		Ecercise4 vn=new Ecercise4();
		vn.checkNames();
		
	}

}
