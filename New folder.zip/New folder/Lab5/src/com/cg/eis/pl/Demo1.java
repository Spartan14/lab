package com.cg.eis.pl;
import com.cg.eis.bean.*;
import java.util.Scanner;
import com.cg.eis.bean.Exercise1.*;
public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Exercise1 fc=new Exercise1();
		String sig=sc.nextLine();
		fc.TraficLight(sig);
		
	}

}
