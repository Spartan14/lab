package com.cg.eis.exception;

public class EmptyException extends Exception {
	public EmptyException() {
		
	}
	public EmptyException(String message) {
		super(message);
	}
	public String toString() {
		return "cg.exception.EmptyException : "+super.getMessage();
	}
}
