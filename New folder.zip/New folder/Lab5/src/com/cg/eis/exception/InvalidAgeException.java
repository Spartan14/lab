package com.cg.eis.exception;
import javax.xml.ws.handler.MessageContext;
public class InvalidAgeException extends Exception{
	public InvalidAgeException()
	{
		
	}
	public InvalidAgeException(String message)
	{
		super(message);
	}
	public String toString()
	{
		return "cg.Exception.InvalidAgeException "+super.getMessage();
	}

}
