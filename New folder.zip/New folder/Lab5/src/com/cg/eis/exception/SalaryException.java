package com.cg.eis.exception;

public class SalaryException extends Exception {
	public SalaryException(){
	
	
	}
	public SalaryException(String message)
	{
		super(message);
	}
	public String toString()
	{
		return "cg.Exception.SalaryException "+super.getMessage();
	}

}
