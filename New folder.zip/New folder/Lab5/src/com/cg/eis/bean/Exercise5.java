package com.cg.eis.bean;
import com.cg.eis.exception.InvalidAgeException;
public class Exercise5 {
	private String name;
	private int age;
	public Exercise5() {
		// TODO Auto-generated constructor stub
	}
	public Exercise5(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Person[name="+name+",age="+age+"]";
	}
	public void Details(String name,int age)throws InvalidAgeException
	{
		if(age<15)
		{
			throw new InvalidAgeException("Invalid age");
		}
		else
		{
			System.out.println(name);
			System.out.println(age);
		}
	}

}
