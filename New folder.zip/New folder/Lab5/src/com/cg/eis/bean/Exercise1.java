package com.cg.eis.bean;

public class Exercise1 {
	public void TraficLight(String ch) {
		switch (ch) {
		case "Red":
		System.out.println("Stop");
		break;
		case "Yellow":
		System.out.println("Ready");
		break;
		case "Green":
		System.out.println("Go");
		break;
		default:
			System.out.println("Invalid Statement");
			break;
		}
	}
	

}
