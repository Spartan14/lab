package com.cg.eis.bean;

public class Exercise3 {
	public void getPrimes(int n) {
		int flag=0,j;
		for(int i=1;i<=n;i++)
		{
			for(j=2;j<i;j++)
			{
				if(i%j==0)
					break;
				else
					flag=1;
			}
			if(i==j)
				System.out.println(i+" ");
		}
	}

}
