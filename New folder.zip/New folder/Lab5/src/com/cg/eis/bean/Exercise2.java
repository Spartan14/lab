package com.cg.eis.bean;

public class Exercise2 {
	public int recursiveFib(int n)
	{
		if(n==0)
			return 0;
		else
			if(n==1)
				return 1;
			else
				return(recursiveFib(n-1)+recursiveFib(n-2));
	}
	public void fib(int n)
	{
		int t1=0,t2=1,sum=0;
		System.out.println("Using Non-Recursive function : ");
		for(int i=1;i<n;i++)
		{
			System.out.println(t1+" ");
			sum=t1+t2;
			t2=t1;
			t1=sum;
		}
		System.out.println();
	}

}
