package com.cg.eis.bean;

import com.cg.eis.exception.SalaryException;

public class Exercise6 {
	private String ename;
	private int salary;
	public Exercise6() {
		// TODO Auto-generated constructor stub
	}
	public Exercise6(String ename, int salary) {
		super();
		this.ename = ename;
		this.salary = salary;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Exercise6 [ename=" + ename + "]";
	}
	public void chesksal(double sal)throws SalaryException
	{
		if(sal<3000)
		{
			throw new SalaryException("Salary should be more than 3000");
		}
		else
		{
			System.out.println(sal);
		}
	}
}
