package com.cg.eis.bean;
import com.cg.eis.exception.EmptyException;
public class Ecercise4 {
	private String firstName;
	private String lastName;
	public Ecercise4() {
		// TODO Auto-generated constructor stub
	}
	
	public Ecercise4(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void checkNames() throws EmptyException
	{
		if((firstName==null) && (lastName==null))
			throw new EmptyException("Both values are empty");
		else
			System.out.println("Your correct");
	}

}
