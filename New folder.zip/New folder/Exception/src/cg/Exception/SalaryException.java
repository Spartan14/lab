package cg.Exception;

public class SalaryException extends Exception {
	public SalaryException() {
		// TODO Auto-generated constructor stub
	}
	public SalaryException(String message){
	super(message);
	}
	public String toString()
	{
		return "cg.Exception.Salary Exception" +super.getMessage();
	}
	
}
