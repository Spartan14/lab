package cg;

import java.io.IOException;

public class Demo6 {
	public static void checkSal(int x)
	{
		if(x<=3000)
		{
			throw new RuntimeException(x+", salary should be morethan 3000");//unchecked exception
		}
	}
	public static void main(String[] args) {
		int a=0;
		try
		{//to monitor the code for errors 
		a=Integer.parseInt(args[0]);
		checkSal(a);
		System.out.println(a);
		}//end of try
		catch(Exception e)//Exception handler block
		{
			System.out.println("No Arguments has passed");
			System.out.println("Message from exception is :"+e.getMessage());
			e.printStackTrace();//JVM stackTrace
		}
		System.out.println("Continue program");
	}
}
/*
1.no command line argument ==>
2.args[0]="aa" ==>NumberFormatException
3.args[0]=0 ==>ArithematicException
4.args[0]=20

*/