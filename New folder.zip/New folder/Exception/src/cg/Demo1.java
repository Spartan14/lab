package cg;
public class Demo1 {
	public static void change(int x)
	{
		x=100/x;
	}
	public static void main(String[] args) {
		int a=0;
		a=Integer.parseInt(args[0]);
		change(a);
		System.out.println(a);
		System.out.println("Continue program");
		}
}
/*
1.no command line argument ==>
2.args[0]="aa" ==>NumberFormatException
3.args[0]=0 ==>ArithematicException
4.args[0]=20

*/