package com.cg.eis.bean;
import java.io.*;
public class Exercise1 {   //lab 10_1
	FileInputStream fromFile;
	FileOutputStream toFile;

	public void init(String arg1,String arg2)throws IOException{
		// TODO Auto-generated method stub
		try{
			fromFile=new FileInputStream(arg1);
			toFile=new FileOutputStream(arg2);
		}catch(FileNotFoundException fe){
			System.out.println("Exception :"+fe);
			throw fe;
			
			}

	}
	public void copyContents()throws IOException, InterruptedException{
		//copy bytes
		try{
			int i=fromFile.read();
			int chaCount=0;
			while(i!=-1)
			{
				chaCount++;
				if(chaCount==10)
				{
					System.out.println("\n10 Characters Copied");
					chaCount=0;
					Thread.sleep(9500);
				}
				toFile.write(i);
				i=fromFile.read();
			}
		}
			catch(IOException ioe){
				System.out.println("Exception :"+ioe);
				throw ioe;
			}
			finally
			{
				if(fromFile!=null)
				{
					fromFile.close();//throws IOException
				}
				if(toFile!=null)
				{
					toFile.close();//throws IOException
				}
			}
		}
}
