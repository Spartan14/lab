package com.cg.eis.pl;

import com.cg.eis.bean.Exercise2;

public class Demo2 {        //demo lab 10_2

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise2 l2=new Exercise2();
		Thread itThread=new Thread(l2);
		itThread.start();

	}

}
