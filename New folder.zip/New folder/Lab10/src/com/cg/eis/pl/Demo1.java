package com.cg.eis.pl;

import java.io.IOException;

import com.cg.eis.bean.Exercise1;  //demo lab 10_1

public class Demo1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Exercise1 ex=new Exercise1();
		try {
			ex.init("source.txt","target.txt");
			ex.copyContents();
		}
		catch(IOException e)
		{
			System.out.println("Caught in main\t:"+e.getMessage());
		}

	}

}
