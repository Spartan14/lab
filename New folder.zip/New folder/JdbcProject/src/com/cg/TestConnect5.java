package com.cg;
import java.sql.*;
import java.util.*;
public class TestConnect5 {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		//Load the driver
		
			try {
				
			//	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String user="trg531";
		String pass="training531";
		
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		con.setAutoCommit(false);//tells that do not commit after every dml statement
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Department ID");
		int d=sc.nextInt();
		System.out.println("Enter Department Name");
		String dn=sc.next();
		System.out.println("Enter Department Location");
		String loc=sc.next();
		//Dynamic query
		
		String sqlQuery="Insert into dept values(?,?,?)";
		
		
		PreparedStatement st=con.prepareStatement(sqlQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);//used to pass sql queries
		st.setInt(1, d);
		st.setString(2, dn);
		st.setString(3, loc);
		
		
		int insertedRec=st.executeUpdate();
		System.out.println("Inserted records"+insertedRec);
		
	/*	ResultSet rs=st.executeQuery();
		
		if(rs.next())
		{
			int d_id=rs.getInt("did");
			if(d_id==50)
			{
				rs.updateString("dname","Admin");
				rs.updateString(3,"Chennai");
				rs.updateRow();
			}
			String d_name=rs.getString("dname");
			String loc=rs.getString(3);
			System.out.println("Dept id:\t"+d_id+"\tName:\t"+d_name+"loc:\t"+loc);
			System.out.println("================================================================");
			
		}*/
		con.commit();
		con.close();
	}
	catch(SQLException e)
			{
		System.out.println(e.getMessage()+""+e.getErrorCode()+""+e.getSQLState());}
			}
}

