package com.cg;
import java.sql.*;
import java.util.*;
public class TestConnect7 {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		//Load the driver
		
			try {
				
			//	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String user="trg531";
		String pass="training531";
		
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		con.setAutoCommit(false);//tells that do not commit after every dml statement
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Department ID");
		int d=sc.nextInt();
		
		//Dynamic query
		
		String sqlQuery="delete from dept where did=?";
		
		
		PreparedStatement st=con.prepareStatement(sqlQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);//used to pass sql queries
		st.setInt(1, d);
		
		
		
		int deleteRec=st.executeUpdate();
		System.out.println("Delete records"+deleteRec);
		
		con.commit();
		con.close();
	}
	catch(SQLException e)
			{
		System.out.println(e.getMessage()+""+e.getErrorCode()+""+e.getSQLState());}
			}
}

