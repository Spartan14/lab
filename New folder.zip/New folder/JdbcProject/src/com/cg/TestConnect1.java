package com.cg;
import java.sql.*;
public class TestConnect1 {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		//Load the driver
		
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		
		String user="trg531";
		String pass="training531";
		
		Connection con=DriverManager.getConnection(url, user, pass);
		System.out.println("Connected");
		Statement st=con.createStatement();//used to pass sql queries
		ResultSet rs=st.executeQuery("select * from dept");
		while(rs.next())
		{
			int d_id=rs.getInt("did");
			String d_name=rs.getString("dname");
			String loc=rs.getString(3);
			System.out.println("Dept id:\t"+d_id+"\tName:\t"+d_name+"loc:\t"+loc);
			System.out.println("==========================");
		}
		
		con.close();
	}

}
