package com.cg.eis.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.eis.bean.Account;
import java.sql.*;
public class AccountDaoImpl implements AccountDao {
	
	Connection con;
	PreparedStatement pst;
	
	//Wallet Account DataBase
	Map<Integer,Account> walletAccounts=new ConcurrentHashMap<>();
	
	private void makeConnection()
	{
		try
		{
			String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
			String user="trg531";
			String pass="training531";
			
			con=DriverManager.getConnection(url, user, pass);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	private void releaseConnection()
	{
		try
		{
			if(con!=null)
				con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	/*
	 * Method to insert new account in a database
	 */
	@Override
	public boolean createAccount(Account ac) {
		
		walletAccounts.put(ac.getMobile(),ac);
		Account ac1=walletAccounts.get(ac.getMobile());
		if(ac1!=null)
		{
			try
			{
			makeConnection();
			pst=con.prepareStatement("Insert into account values(?,?,?,?)");
			pst.setInt(1, ac.getAccountNo());
			pst.setString(2, ac.getName());
			pst.setLong(3, ac.getMobile());
			pst.setDouble(4, ac.getBal());
			int insert=pst.executeUpdate();
			System.out.println("Inserted into database"+insert);
			releaseConnection();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
			return true;
	}
	else
		return false;
		

}
	/*
	 * Method to retrieve account by mobile number from database
	 */
	@Override
	public Account getAccountByMobile(int mobileNo) {
		Account ac=walletAccounts.get(mobileNo);
		if(ac!=null)
			return ac;
		else
		return null;
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return walletAccounts;
	}
	@Override
	public boolean updateAccount(Account ac) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean deleteAccount(int mobile) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean transferMoneyAccount(Account a1, Account a2) {
		boolean transfered=false;
		try
		{
			makeConnection();
			con.setAutoCommit(false);
			pst=con.prepareStatement("Update account set balance=?where acno=?");
			pst.setDouble(1, a1.getBal());
			pst.setInt(2, a1.getAccountNo());
			int u1=pst.executeUpdate();
			System.out.println("Updated account 1 in database"+u1);
			pst=con.prepareStatement("Update account set balance=?where acno=?");
			pst.setDouble(1, a2.getBal());
			pst.setInt(2, a2.getAccountNo());
			int u2=pst.executeUpdate();
			System.out.println("Updated account 2 in database"+u2);
			
			walletAccounts.put(a1.getMobile(), a1);
			walletAccounts.put(a2.getAccountNo(), a2);
			transfered=true;
			con.commit();
			releaseConnection();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			transfered= false;
		}
		// TODO Auto-generated method stub
		return transfered;
	}

}
