package com.cg.pizzaorder.dao;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.exception.PizzaException;
public class PizzaOrderDAO implements IPizzaOrderDAO{
 //map for order id as key and pizza order as value
 Map<Integer,PizzaOrder> pizzaEntry =new ConcurrentHashMap<Integer, PizzaOrder>();
 //map for customer id as key and customer object as value
 Map<Integer,Customer> customerEntry =new ConcurrentHashMap<Integer, Customer>();

 @Override
 public int placeOder(Customer customer, PizzaOrder pizza) throws PizzaException {
 // TODO Auto-generated method stub
 pizzaEntry.put(pizza.getOrderid(), pizza);//putting pizza order to pizza map
 customerEntry.put(pizza.getCustomerId(), customer);//putting customer order to customer map.
 PizzaOrder p=pizzaEntry.get(pizza.getOrderid());
 if(p!=null)
  return pizza.getOrderid();
 else
  return 0;
 }
 @Override
 public PizzaOrder getOderDetails(int orderId) throws PizzaException {
 // TODO Auto-generated method stub
 PizzaOrder po=pizzaEntry.get(orderId);
 if(po!=null)
  return po;
 else
  return null;

 }

}

