package com.cg.pizzaorder.exception;
public class PizzaException extends Exception{
 public PizzaException() {
 // TODO Auto-generated constructor stub

 }
 //sending message super class
 public PizzaException(String message) {

 super(message);

 }
 //get the message and sending to exception

 @Override
 public String toString() {
 return "cg.pizzaorder.exception :"+super.getMessage();

 }
}


