package com.cg.pizzaorder.service;
import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.dao.*;
import com.cg.pizzaorder.exception.PizzaException;


public class PizzaOrderService implements IPizzaOrderService {
 IPizzaOrderDAO pizzaDao=new PizzaOrderDAO();

@Override
public int placeOder(Customer customer, PizzaOrder pizza) throws PizzaException {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public PizzaOrder getOderDetails(int orderid) throws PizzaException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public int GenOrderId() {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public int GenCustId() {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public boolean validatePhone(String mobile) throws PizzaException {
	// TODO Auto-generated method stub
	return false;
}

@Override
public int placeOrder(Customer customer) {
	// TODO Auto-generated method stub
	return 0;
}


}

