package com.cg.pizzaorder.service;
import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService {
 String mobilePattern="[0-9]{10}";
 public int placeOder(Customer customer,PizzaOrder pizza)throws PizzaException;//take the details of customer and pizza
 public PizzaOrder getOderDetails(int orderid) throws PizzaException;//to get the pizza details using order id
 public int GenOrderId();
 public int GenCustId();
 public boolean validatePhone(String mobile) throws PizzaException;
int placeOrder(Customer customer);

}

