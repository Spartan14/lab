package com.cg.eis.bean;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Exercise1 {
	public int numbersorting(int a[]) {
		
		Arrays.sort(a);
		return a[1];
		
	}

}
