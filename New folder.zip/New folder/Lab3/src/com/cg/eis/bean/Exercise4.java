package com.cg.eis.bean;

public class Exercise4 {
	
	public void countChar(char arr[])
	{
		int len=arr.length;
		int count=0;
		for(int i=0;i<len;i++)
		{
			count=0;
			char ch=arr[i];
			for(int j=0;j<len;j++)
			{
				if(j<i && ch==arr[j])
				{
					break;
				}
				if(arr[j]==ch)
					count++;
			}
			if(count>0)
				System.out.println("count of "+arr[i]+" is : "+count);
		}
	}

}
