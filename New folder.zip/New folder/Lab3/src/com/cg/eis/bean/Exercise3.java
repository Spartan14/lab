package com.cg.eis.bean;

import java.util.Arrays;

public class Exercise3 {
	public static int[] getSorted(int p[],int size)
			{
		int j=0,num=0;
		int c[]=new int[size];
		for(j=0;j<size;j++)
		{
			while(p[j]!='\0')
			{
				num=p[j]%10;
				c[j]=(c[j]*10)+num;
				p[j]/=10;
			}
		}
			Arrays.sort(c);
			return c;
			}
}
