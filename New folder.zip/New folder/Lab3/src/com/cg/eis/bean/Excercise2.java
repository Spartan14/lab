package com.cg.eis.bean;

import java.io.IOException;
import java.util.Arrays;

public class Excercise2 {
	public  String[] stringSort(String s[]) {
		Arrays.sort(s);
		String s2[]=new String[5];
		for(String s1 : s)
		{
			System.out.println(s1);
		}
		int length=s.length;
		int b;
		if((length%2)==0)
		{
			b=length/2;
			for(int i=0;i<b;i++)
			{
				s2[i]=s[i].toUpperCase();
			}
			for(int i=b;i<length;i++)
			s2[i]=s[i].toLowerCase();
		}
		else
		{
			b=(length/2);
			for(int i=0;i<b;i++)
			{
				s2[i]=s[i].toUpperCase();
			}
			for(int i=b;i<length;i++)
				s2[i]=s[i].toLowerCase();
			}
		return s2;
	}
}
