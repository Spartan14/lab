package com.cg.eis.pl;

import java.util.Scanner;


import com.cg.eis.bean.Exercise1;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array=new int[4];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Elements");
		for(int i = 0;i<array.length;i++)
			array[i]=sc.nextInt();
		Exercise1 sc1=new Exercise1();
		System.out.println("Second smallest number is :"+sc1.numbersorting(array));
		

	}

}
