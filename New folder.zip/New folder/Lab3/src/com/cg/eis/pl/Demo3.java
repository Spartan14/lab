package com.cg.eis.pl;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
import com.cg.eis.bean.*;
public class Demo3 {
	public static void main(String[] args) throws NumberFormatException,IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Exercise3 m=new Exercise3();
		System.out.println("Enter the size of array :");
		int n=Integer.parseInt(br.readLine());
		int a[]=new int[n];
		int b[]=new int[n];
		System.out.println("Enter the elements :");
		for(int i=0;i<n;i++)
		{
			a[i]=Integer.parseInt(br.readLine());
		}
		System.out.println("The input elements are :");
		for(int i=0;i<n;i++)
		{
			System.out.println(a[i]);
		}
		b=m.getSorted(a,n);
		for(int i=0;i<n;i++)
		{
		System.out.println("After sorting the elements are :\t"+b[i]);	
		}
		}

}
