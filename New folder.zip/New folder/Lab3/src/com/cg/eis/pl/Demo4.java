package com.cg.eis.pl;

import java.io.IOException;
import java.util.Scanner;

import com.cg.eis.bean.Exercise4;

public class Demo4 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		Exercise4 l4=new Exercise4();
		Scanner br=new Scanner(System.in);
		System.out.println("Enter length of character array : ");
		int len=br.nextInt();
		System.out.println("Enter char values into array : ");
		char ch[]=new char[len];
		for(int i=0;i<ch.length; i++)
		{
			ch[i]=br.next().charAt(0);
		}
		l4.countChar(ch);

	}

}
