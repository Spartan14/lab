package com.cg.eis.pl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import com.cg.eis.bean.*;
public class Demo2 {

		public static void main(String[] args) throws NumberFormatException,IOException
		{
			Excercise2 e2 = new Excercise2();
			String[] s= {"Venky","Balu","Hello","Buddy"};
			String[] k=new String[4];
				k=e2.stringSort(s);
				System.out.println("After converting=====");
				for(int i=0;i<s.length;i++)
				{
					System.out.println(k[i]);
				}
			}
		

}
