package cg.ui;
import java.io.IOException;
import java.io.RandomAccessFile;
public class RandomAccessFileExample {
	public static void main(String[] args) {
		try{
			String filePath="data.txt";
			String data=new String(readCharsFromFile(filePath,0));
			System.out.println(data);
			
			writeData(filePath,"Hello",data.length());
			
			appendData(filePath," Balu");
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	private static void appendData(String filePath,String data)throws IOException{
		RandomAccessFile raFile=new RandomAccessFile(filePath,"rw");
		raFile.seek(raFile.length());
		System.out.println("Current pointer = "+raFile.getFilePointer());
		raFile.write(data.getBytes());
		raFile.close();
	}
private static void writeData(String filePath,String data,int seek)throws IOException{
	RandomAccessFile file=new RandomAccessFile(filePath,"rw");
	file.seek(seek);
	file.write(data.getBytes());
	file.close();
}
private static byte[]readCharsFromFile(String filePath,int seek)throws IOException{
	RandomAccessFile file=new RandomAccessFile(filePath,"r");
	file.seek(seek);
	byte[]bytes=new byte[(int)file.length()];
	file.read(bytes);
	file.close();
	return bytes;
	
}
}
