package cg.ui;
import java.io.*;
import com.cg.bean.*;

public class ArrayDemo {
	public static void main(String[] args)throws IOException{
		Employee emp[]=new Employee[3];
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		for(int i=0;i<emp.length;i++){
			System.out.println("Enter Employee eid");
			String seid=br.readLine();
			int id=Integer.parseInt(seid);
			
			System.out.println("Enter Employee name");
			String name=br.readLine();
			
			
			System.out.println("Enter Employee salary");
			String ssal=br.readLine();
			double sal=Double.parseDouble(ssal);
			
			
			
			emp[i]=new Employee(id,name,sal);
			
	}
	for(Employee e:emp){
		System.out.println(e);
	}
	}
}

