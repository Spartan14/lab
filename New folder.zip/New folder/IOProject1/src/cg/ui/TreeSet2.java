package cg.ui;
import java.io.*;

import com.cg.bean.*;

import java.util.*;


public class TreeSet2 {
	public static void main(String[] args)throws IOException{
		TreeSet<Employee>elist=new TreeSet<Employee>();//Growable or shrinkable list for collection of Employee objects
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("No of Employees");
		int no=Integer.parseInt(br.readLine());
	
		for(int i=0;i<=no;i++){
			System.out.println("Enter Employee eid");
			String seid=br.readLine();
			int id=Integer.parseInt(seid);
			
			System.out.println("Enter Employee name");
			String name=br.readLine();
			
			
			System.out.println("Enter Employee salary");
			String ssal=br.readLine();
			double sal=Double.parseDouble(ssal);
			
			
			Employee ob=new Employee(id,name,sal);
			boolean added=elist.add(ob);
			System.out.println("Added Employee "+added);
			
	}
	for(Employee e:elist){
		System.out.println(e);//e.toString
	}
	}
}
