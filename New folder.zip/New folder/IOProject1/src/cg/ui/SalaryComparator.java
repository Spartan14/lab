package cg.ui;

import java.util.Comparator;

import com.cg.bean.Employee;

public class SalaryComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee arg0, Employee arg1) {
		System.out.println("Compare Method for sorting Employee salary");
		double diff=arg0.getSalary()-arg1.getSalary();
		if(diff>0) return 1;
		else if(diff<0) return -1;
		else return 0;
		
	}
}