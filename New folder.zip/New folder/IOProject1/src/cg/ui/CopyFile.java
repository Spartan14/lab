package cg.ui;
import java.io.*;
public class CopyFile {
	FileInputStream fromFile;
	FileOutputStream toFile;

	public void init(String arg1,String arg2)throws IOException{
		// TODO Auto-generated method stub
		try{
			fromFile=new FileInputStream(arg1);
			toFile=new FileOutputStream(arg2);
		}catch(FileNotFoundException fe){
			System.out.println("Exception :"+fe);
			throw fe;
			
			}

	}
	public void copyContents()throws IOException{
		//copy bytes
		try{
			int i=fromFile.read();
			while(i!=-1){//check the end of file
				toFile.write(i);
				i=fromFile.read();
			}
		}
			catch(IOException ioe){
				System.out.println("Exception :"+ioe);
				throw ioe;
			}
			finally
			{
				if(fromFile!=null)
				{
					fromFile.close();//throws IOException
				}
				if(toFile!=null)
				{
					toFile.close();//throws IOException
				}
			}
			
		}
		public static void main(String[] args){
			CopyFile c1=new CopyFile();
			try
			{
				c1.init("aa.txt","bb.txt");
				c1.copyContents();
			}
			catch(IOException e)
			{
				System.out.println("Caught in main "+e);
			
			}
		
	}

}
