package cg.ui;
import java.io.*;
import com.cg.bean.*;
public class SerializationDemo {
	public static void serialize(Employee e)throws IOException
	{
		FileOutputStream fo=new FileOutputStream("emp.ser");
		ObjectOutputStream obs=new ObjectOutputStream(fo);
		obs.writeObject(e);
		fo.close();
		obs.close();
	}
	public static void main(String[] args)throws IOException{
		Employee e=new Employee(100,"Bum",25000.00);
		e.os="Windows";
		System.out.println(e);
		serialize(e);
	}
}
