package cg.ui;
import com.cg.bean.*;
import java.util.*;

public class NameComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee arg0, Employee arg1) {
		System.out.println("Compare Method for sorting Employee name");
		int res=arg0.getEname().compareTo(arg1.getEname());
		return res;
	}
	

}
