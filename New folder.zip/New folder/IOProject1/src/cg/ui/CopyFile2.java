package cg.ui;
import java.io.*;
public class CopyFile2 {
	BufferedReader br;
	PrintWriter out;
	FileReader fromFile;
	FileWriter toFile;

	public void init(String arg1,String arg2)throws IOException{
		// TODO Auto-generated method stub
		try{
			fromFile=new FileReader(arg1);
			br=new BufferedReader(fromFile);
			
			toFile=new FileWriter(arg2);
			out=new PrintWriter(toFile,true);
			
		}catch(FileNotFoundException fe){
			System.out.println("Exception :"+fe);
			throw fe;
			
			}
		catch(IOException fe){
			System.out.println("Exception :"+fe);
			throw fe;
		}

	}
	public void copyContents()throws IOException{
		//copy bytes
		try{
			String line=br.readLine();
			while(line!=null){//check the end of file
				out.println(line);
				line=br.readLine();
			}
		}
			catch(IOException ioe){
				System.out.println("Exception :"+ioe);
				throw ioe;
			}
			finally
			{
				if(fromFile!=null)
				{
					fromFile.close();//throws IOException
				}
				if(toFile!=null)
				{
					toFile.close();//throws IOException
				}
			}
			
		}
		public static void main(String[] args){
			CopyFile2 c1=new CopyFile2();
			try
			{
				c1.init("aa.txt","dd.txt");
				c1.copyContents();
			}
			catch(IOException e)
			{
				System.out.println("Caught in main "+e);
			
			}
		
	}

}
