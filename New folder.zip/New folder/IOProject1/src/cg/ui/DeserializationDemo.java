package cg.ui;
import com.cg.bean.*;
import java.io.*;

import com.cg.bean.*;
public class DeserializationDemo {
	public static Employee deserialize()throws IOException,ClassNotFoundException
	{
		FileInputStream fi=new FileInputStream("emp.ser");
		ObjectInputStream obsi=new ObjectInputStream(fi);
		Employee emp=(Employee)obsi.readObject();
		fi.close();
		obsi.close();
		return emp;
	}
	public static void main(String[] args)throws IOException,ClassNotFoundException{
		Employee e=deserialize();
		System.out.println(e);
	}
}