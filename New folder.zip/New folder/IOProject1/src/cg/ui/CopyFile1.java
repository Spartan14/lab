package cg.ui;
import java.io.*;
public class CopyFile1 {
	FileReader fromFile;
	FileWriter toFile;

	public void init(String arg1,String arg2)throws IOException{
		// TODO Auto-generated method stub
		try{
			fromFile=new FileReader(arg1);
			toFile=new FileWriter(arg2);
		}catch(FileNotFoundException fe){
			System.out.println("Exception :"+fe);
			throw fe;
			
			}
		catch(IOException fe){
			System.out.println("Exception :"+fe);
			throw fe;
		}

	}
	public void copyContents()throws IOException{
		//copy bytes
		try{
			int i=fromFile.read();
			while(i!=-1){//check the end of file
				toFile.write(i);
				i=fromFile.read();
			}
		}
			catch(IOException ioe){
				System.out.println("Exception :"+ioe);
				throw ioe;
			}
			finally
			{
				if(fromFile!=null)
				{
					fromFile.close();//throws IOException
				}
				if(toFile!=null)
				{
					toFile.close();//throws IOException
				}
			}
			
		}
		public static void main(String[] args){
			CopyFile1 c1=new CopyFile1();
			try
			{
				c1.init("aa.txt","cc.txt");
				c1.copyContents();
			}
			catch(IOException e)
			{
				System.out.println("Caught in main "+e);
			
			}
		
	}

}
