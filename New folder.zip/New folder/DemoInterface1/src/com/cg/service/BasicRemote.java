package com.cg.service;
//sub interface
public interface BasicRemote {
	public void Switchon();
	public void Switchoff();
	

}
