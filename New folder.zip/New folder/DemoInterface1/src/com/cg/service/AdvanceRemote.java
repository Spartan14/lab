package com.cg.service;

public interface AdvanceRemote extends BasicRemote {
	public void AccessInternet();
	
}
