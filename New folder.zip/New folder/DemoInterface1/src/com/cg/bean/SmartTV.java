package com.cg.bean;
import com.cg.service.AdvanceRemote;

public class SmartTV implements AdvanceRemote{


	@Override
	public void Switchon() {
		// TODO Auto-generated method stub
		System.out.println("Switch on TV");
		
	}

	@Override
	public void Switchoff() {
		// TODO Auto-generated method stub
		System.out.println("Switch off TV");
		
	}
	//super interface methods

	@Override
	public void AccessInternet() {
		// TODO Auto-generated method stub
		System.out.println("Access Internet");
		
	}
	
}
