package com.cg.ui;
import com.cg.bean.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SmartTV sm=new SmartTV();
		sm.Switchon();
		sm.Switchoff();
		sm.AccessInternet();

	}

}
