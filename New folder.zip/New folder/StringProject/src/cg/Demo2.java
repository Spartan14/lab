package cg;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String s1="Balu";
		//String s2="Balu";
		String s1=new String("Balu");
		String s2=new String("Balu");
		String s3="balu";
		
		if(s1==s2)
			System.out.println("Identical");
		else
			System.out.println("Not Identical");
		
		if(s1.equals(s2))
			System.out.println("Matching content with case");
		else
			System.out.println("Not matching content");
		
		if(s2.equalsIgnoreCase(s3))
			System.out.println("Matching content without case");

	}

}
