package cg;

public class Demo3 {

	private static final char[] P1 = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="";
		String s2="Cap Gemini Solutions Private Limited.........";
		String s;
		if(s1.equals("")) System.out.println("Empty string");//all versions
		if(s1.isEmpty()) System.out.println("String is empty");//jdk 1.6 onwords
		int len=s2.length();
		System.out.println("Length means no of chars in a string"+len);
		int ind=s2.indexOf("Gemini");
		System.out.println(ind);
		s=s2.substring(4,10);//part of the string
		System.out.println(s);
		String name="  Balu  ";
		System.out.println(name);
		name=name.trim();
		double doubleP1 = 3.14;
		s=String.valueOf(P1);
		System.out.println(s);
	}

}
