package com.cg.eis.service;
import java.util.Map;
import com.cg.eis.bean.Account;
public interface WalletService {
	String mobilePattern="[0-9] {10}";//10 digit pattern for mobile no final and static
	public boolean validateMobile(String mobile);
	public boolean createAccount(Account ac);
	public Account getAccountByMobile(int mobileNo);
	public Map<Integer,Account> getAllAccount();

}