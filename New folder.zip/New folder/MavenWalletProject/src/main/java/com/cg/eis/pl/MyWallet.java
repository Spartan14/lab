package com.cg.eis.pl;
import com.cg.eis.service.*;

import java.util.Map;

import com.cg.eis.bean.*;
public class MyWallet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WalletService service=new WalletServiceImpl();
		
		Account ob1=new Account(100,1111111111,"Balu",32000.00);
		boolean added=service.createAccount(ob1);
		System.out.println("Account added\t:\t"+added);
		
		Account ob2=new Account(101,222222222,"Venky",42000.00);
		added=service.createAccount(ob2);
		System.out.println("Account added\t:\t"+added);
		
		Map<Integer,Account>allac=service.getAllAccount();
		System.out.println(allac);
		
		Account myac=service.getAccountByMobile(1111111111);
		System.out.println(myac);


	}

}
