package com.cg.eis.bean;

public class Account {
	private int accountNo;
	private int mobile;
	private String name;
	private double bal;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(int accountNo, int mobile, String name, double bal) {
		super();
		this.accountNo = accountNo;
		this.mobile = mobile;
		this.name = name;
		this.bal = bal;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", mobile=" + mobile + ", name=" + name + ", bal=" + bal + "]";
	}
	

}
