package com.cg.eis.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

import org.junit.jupiter.api.Test;

import com.cg.eis.bean.Account;

class WalletServiceTest {

	@Test
	void test() {
		//fail("Not yet implemented");
		WalletService service = new WalletServiceImpl();
		System.out.println("test");
		assertTrue(service.createAccount(new Account(1,349934943,"aa",4343.00)));
		
	}

}
