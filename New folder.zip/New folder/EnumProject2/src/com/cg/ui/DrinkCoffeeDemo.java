package com.cg.ui;
import com.cg.bean.*;
public class DrinkCoffeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coffee c1=new Coffee(Size.SMALL,100.00);
		System.out.println(c1);
		Size s=c1.getSize();
		int ml=s.getMl();
		System.out.println("Amount is : "+ml+"ml");

	}

}
