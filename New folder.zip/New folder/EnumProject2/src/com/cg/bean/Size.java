package com.cg.bean;

public enum Size {
	SMALL(100),
	MEDIUM(200),
	LARGE(300);
	
	private int ml;
	private Size(int ml)
	{
		this.ml=ml;
	}
	public int getMl()
	{
		return ml;
	}
}
// All values are by default public final and static
//Size.SMALL ===>Small(100)=> public final static Size SMALL=new Size(100);
