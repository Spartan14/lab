package cg.bean;

public abstract class Account {
	private String name;
	private int accno;
	private double balance;
	public void print()
	{
		System.out.println("+name+accno+"+balance);
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Account(String name, int accno, double balance) {
		super();
		this.name = name;
		this.accno = accno;
		this.balance = balance;
	}

	public void printDetails()
	{
		System.out.println("Account no :"+accno+"\nBalance is :"+balance+"\nCustomer name :"+name);
	}
	public abstract double withdraw(double amount);
	public abstract double deposite(double amount);

}
