package com.cg.ui;

import com.cg.bean.Account;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account ac=new Account(123456,"Balu",25000.0);
		ac.printDetails();
		double with=ac.Withdraw(2000);
		System.out.println("After withdrawl : "+with);
		double dep=ac.deposite(1000);
		System.out.println("After deposite : "+dep);
		
	}

}
