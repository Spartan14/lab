package com.cg;
import java.util.concurrent.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyRunnable r=new MyRunnable();
		Executor executor=Executors.newSingleThreadExecutor();
		executor.execute(r);//Automatic thread object and start thread and execute
		executor.execute(r);
		executor.execute(r);

	}

}
