package com.cg;
import java.util.concurrent.*;
public class Demo_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Runnable r=()->System.out.println("Happy Birthday Venu");
		Runnable r1=()->System.out.println("Happy Birthday Jagadeesh");
		Runnable r2=()->System.out.println("Happy Birthday To ME");
		
		/*
		 *()->System.out.println("Happy Birthday Venu");
		 //lambda automatically implements Runnable
		 class $$$ implements Runnable
		 {
		 	public void run()
		 	{
		 		System.out.println("Happy Birthday Venu")
		 	}
		 } 
		 */
		ExecutorService executor=Executors.newFixedThreadPool(4);
		executor.execute(r);//Automatic thread object and start thread and execute
		executor.execute(r1);
		executor.execute(r2);
		executor.shutdown();

	}

}
