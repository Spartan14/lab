package com.cg;

public class Transaction {
	private double balance;
	
	public Transaction(double balance) {
		this.balance = balance;
	}
	public double deposite(double amount)
	{
		if(amount<=0)
		{
			throw new IllegalArgumentException("Negative amount");
		}
		else
		{
			balance=balance+amount;
		}
		return balance;
	}

}
