package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.cg.Calculator;

class CalculatorTest1 {
	
	static Calculator ob;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("CalculatorTest1 : Before all test");
		ob=new Calculator();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("CalculatorTest1 : After all test");
		ob=null;
	}

	@Test
	void testupperString() {
		System.out.println("CalculatorTest1 : test case testupperString");
		assertNotNull(ob.upperString("cg"));//ob.upperString("cg")!=null
		assertNull(ob.upperString(null));//ob.upperString("cg")==null
		assertEquals("CG",ob.upperString("cg"));//ob.upperString("cg")=="CG"
	}

	@Test
	void testValidateMobile()
	{
		System.out.println("CalculateTest1 : test case testValidateMobile");
		assertTrue(ob.validateMobile("9493434936"));//ob.validateMobile("9493434936")==true
		assertFalse(ob.validateMobile("939843 0432"));//ob.validateMobile("9398430432")==false
		assertFalse(ob.validateMobile("9955iuftyr"));
		assertFalse(ob.validateMobile("96@kiydras"));
	}
}
