package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.cg.Calculator;

class CalculatorTest2 {

	@ParameterizedTest
	@ValueSource(strings = {"9493434936","1111111111","2222222222"})
	void testValidateMobile(String mobileString)
	{
		System.out.println("CalculatorTest2 : test case testValidateMobile");
		System.out.println("Parameter "+mobileString);
		Calculator ob=new Calculator();
		assertTrue(ob.validateMobile(mobileString));
	}

	@ParameterizedTest
	@CsvSource({"9,4,5","50,20,30","100,50,50"})
	void testadd(int result,int firstno,int secondno)
	{
		System.out.println("CalculatorTest2 : test case testadd");
		System.out.println("Parameter "+result+" "+firstno+" "+secondno);
		Calculator ob=new Calculator();
		assertEquals(result,ob.add(firstno,secondno));
	}

}
