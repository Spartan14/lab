package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import com.cg.Calculator;

class CalculatorTest {

	//@Test
	@RepeatedTest(5)
	void testadd() {
		System.out.println("CalculatorTest : test case testadd");
		Calculator ob=new Calculator();
		assertEquals(9,ob.add(4,5));
	}

}
