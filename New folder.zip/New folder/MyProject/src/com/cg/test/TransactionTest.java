package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.cg.Transaction;

class TransactionTest {
	Transaction t;
	@BeforeAll
	
	static void beforeAllTest()
	{
		System.out.println("TransactionTest : Before all Test");
		
	}
	@BeforeEach
	void BeforeEachTest(){
	System.out.println("transactionTest : Before each test");
	t=new Transaction(1000.00);//object is created each test execution
	}
	@AfterEach
	void AfterEach()
	{
		System.out.println("transactionTest : After each test");
		t=null;
	}
	@Test
	void testdeposite1() {
		System.out.println("TransactionTest : Test case testdeposite");
		assertEquals(3000.00,t.deposite(2000.00));
	}
	@Disabled
	@Test
	void testdeposite2() {
		System.out.println("TransactionTest : Test case testdeposite");
		Throwable ex=assertThrows(IllegalArgumentException.class,()->t.deposite(-2000.00));
		assertEquals("Negative amount",ex.getMessage());
		//()->t.deposite(-2000.00) ->Executable->execute()
		//assertEquals(1000.00,t.deposite(-2000.00));
		
	}
	@AfterAll
	static void afterAllTest()
	{
		System.out.println("transactionTest : After all test");
	}

}
