package cg.ui;
import cg.bean.*;
public class Demo {

	public static void main(String[] args) {
	Test ob=new Test();
	/*ob.add("Hello","CG");
	ob.add("H!!!!",100);
	ob.add(50,"Welcome");
	ob.add(10,20);
	*/
	ob.add(10,20,30);
	int p[]={23,54,65,98,87,23};
	ob.add(p);
	}

}
