package cg.bean;


public class Test {
	//overloaded method have same name
	//but differs in parameters
	//either by data type or
	//by number of parameters
	//by sequence of parameters
	/*
	public void add(String a,String b)
	{
		System.out.println(a+b);
	}
	public void add(String a,int b)
	{
		System.out.println(a+b);
	}
	public void add(int a,String b)
	{
		System.out.println(a+b);
	}
	
	public void add(int a,int b)
	{
		System.out.println(a+b);
	}
	public void add(int a,int b,int c)
	{
		System.out.println(a+b+c);
	}
	public void add(int a[])
	{
		int sum=0;
		for(int x:a)
		{
			sum=sum+x;
		}
		System.out.println(sum);
	}
	*/
//variable arguments //jdk 1.5
//overloaded methods differs only in number of parameters
//but all parameters are same data type
public void add(int...a)
{
System.out.println("Variable argument method");
int sum=0;
for(int x:a)
{
	sum=sum+x;
}
System.out.println(sum);
}
}