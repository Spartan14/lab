package com.cg.ui;

import com.cg.bean.Employee;

public class Demo2 {

	public static void main(String[] args) {
	Employee e=new Employee();
	Employee e1=new Employee(100,"Bum",35000.00);
	Employee e2=new Employee(101,"Dum",22000.00);
	
	System.out.println(e1);
	System.out.println(e2);

	//e1.toString()-->Employee-->super class java.lang.Object
	//Object=>toString()=>prints class name@ hashcode of the object
	String mydefaults="Details of Employee :"+e1;
	System.out.println(mydefaults);
	
	}

}
