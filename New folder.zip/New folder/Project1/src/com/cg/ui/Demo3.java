package com.cg.ui;

import com.cg.bean.Employee;

public class Demo3 {

	public static void main(String[] args) {
	Employee e=new Employee();
	Employee e1=new Employee(100,"Bum",35000.00);
	Employee e2=new Employee(100,"Bum",35000.00);
	
	System.out.println(e1);
	System.out.println(e2);
	System.out.println(e1==e2);
	System.out.println(e1.equals(e2));
	//e1.equals(e2)--> Employee --> java.lang.Object
	//Object equals=>checks for memory address references
	//when you override equals method you have to also override
	System.out.println(e1.hashCode()+" "+e2.hashCode());
	}
	
}