package com.cg.ui;

import com.cg.bean.Employee;

public class Demo1 {

	public static void main(String[] args) {
	Employee e=new Employee();
	Employee e1=new Employee(100,"Bum",35000.00);
	Employee e2=new Employee(101,"Dum",22000.00);
	
	e1=e2;
	//indicate garbage collector to execute
	System.gc();
	System.out.println("Done");
	}

}
