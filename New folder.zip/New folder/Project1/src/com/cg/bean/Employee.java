package com.cg.bean;

public class Employee {
	private int eid;
	private String ename;
	private double salary;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int eid, String ename, double salary) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	//when object is destroyed by garbage collector then finalize method is executed
	public void finalize()
	{
		System.out.println("Destroyed Employee is :"+eid);
	}
	@Override
	public String toString() {
		return "Employee [eid  =  " + eid + ", ename  =  " + ename + ", salary  =  " + salary + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + eid;
		result = prime * result + ((ename == null) ? 0 : ename.hashCode());
		long temp;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		Employee e=(Employee) obj;
		if(this.getEid()==e.getEid()&&
				this.getEname().equals(e.getEname())&&
				this.getSalary()==e.getSalary())
		{
			return true;
		}
		else
			return false;
	}
	
}
