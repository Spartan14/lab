package cg.bean;

import com.cg.service.GST;

public class Savings extends Account implements GST{
	private double interest;
	public Savings() {
		// TODO Auto-generated constructor stub
	}
	
	public double getInterest() {
		return interest;
	}



	public void setInterest(double interest) {
		this.interest = interest;
	}

	public Savings(String name, int accno, double balance, double interest) {
		super(name,accno,balance);
		this.interest = interest;
	}



	@Override
	public double withdraw(double amount) {
		// TODO Auto-generated method stub
	double currentBalance=super.getBalance();
	currentBalance=currentBalance-amount;
	super.setBalance(currentBalance);
	return super.getBalance();
	}

	@Override
	public double calculateGST(double amount) {
		// TODO Auto-generated method stub
		double res=super.getBalance()*fivepct;
		return res;
	}

	@Override
	public double deposite(double amount) {
		// TODO Auto-generated method stub
		double currentbalance=super.getBalance();
		currentbalance=currentbalance=amount;
		super.setBalance(currentbalance);
		return super.getBalance();
	}

}
