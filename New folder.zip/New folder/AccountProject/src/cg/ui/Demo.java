package cg.ui;
import cg.bean.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Account ob=new Savings("Balu", 100000, 5000, 1000);
ob.printDetails();
double with=ob.withdraw(1000);
System.out.println("After withdrawl : "+with);
double dep=ob.deposite(18000);
System.out.println("After deposite : "+dep);
Savings sa=(Savings)ob;
double gstamount=sa.calculateGST(with);
System.out.println("GST is :"+gstamount);
	}

}
