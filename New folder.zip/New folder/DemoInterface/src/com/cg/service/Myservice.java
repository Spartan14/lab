package com.cg.service;

public interface Myservice {
	String wish="Welcome to capgemini";
	public void createWish(String customwish);
	//jdk 1.8 onwords
	//public void aa();//error
	public default void display()
	{
		System.out.println("Default method"+wish);
	}
	public static void mywish()
	{
		System.out.println("static interface method => Static wish is Well done");
	}

}
/*
when interface has single abstract method then it is called functional interface
optionally annoted by
@Functionalinterface
*/