package com.cg.service;

public class MyserviceImpl implements Myservice {

	@Override
	public void createWish(String customwish) {
		// TODO Auto-generated method stub
		System.out.println(customwish);
		
	}
	//no need to implement default method
	//never implement static method
	

}
