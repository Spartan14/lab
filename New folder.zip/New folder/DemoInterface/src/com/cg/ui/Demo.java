package com.cg.ui;

import com.cg.service.Myservice;
import com.cg.service.MyserviceImpl;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myservice.mywish();//static method of interface
		Myservice mys=new MyserviceImpl();
		mys.createWish("Good Morning");
		//override abstrasct method
		mys.display();//default method called

	}

}
