package com.cg.eis.pl;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Exercise2;  ////demo lab 9_2
public class Demo2 {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		Exercise2 l2=new Exercise2();
		Scanner br=new Scanner(System.in);
		System.out.println("Enter length of character array : ");
		int len=br.nextInt();
		System.out.println("Enter char values into Array : ");
		char ch[]=new char[len];
		for(int i=0;i<ch.length;i++)
		{
			ch[i]=br.next().charAt(0);
		}
		HashMap m2=(HashMap) l2.countCharacter(ch);
		System.out.println("Character count in given Array is : ");
		System.out.println(m2);

	}

}
