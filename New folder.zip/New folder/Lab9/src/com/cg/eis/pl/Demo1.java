package com.cg.eis.pl;
import java.util.*;

import com.cg.eis.bean.Exercise1;
public class Demo1 {  //demo lab 9_1

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Number of elements you want to insert : ");
		int size = sc.nextInt();
		
		HashMap<Integer,Integer> m1=new HashMap<Integer,Integer>();
		for(int i=1;i<=size;i++)
		{
			System.out.println("Enter element "+i);
			m1.put(i,sc.nextInt());
		}
		List<Integer> list=new ArrayList<Integer>();
		
		Exercise1 l1=new Exercise1();
		list=l1.getValues(m1,size);
		
		System.out.println("ArrayList : ");
		System.out.println(list);
				

	}

}
