package com.cg.eis.pl;
import com.cg.eis.bean.*;
import java.util.Map;
import java.util.Scanner;

public class Demo3 {  //demo lab 9_3

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise3 hd=new Exercise3();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length : ");
		int len=sc.nextInt();
		int[]arr=new int[len];
		for(int i=0;i<len;i++)
		{
			arr[i]=sc.nextInt();
		}
		Map hm=hd.getValues(arr);
		System.out.println(hm);
	}

}
