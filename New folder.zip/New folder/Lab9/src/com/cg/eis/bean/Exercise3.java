package com.cg.eis.bean;
import java.util.*;
public class Exercise3 {
	public Map getValues(int arr[]) //lab 9_3
	{
		int len=arr.length;
		Map<Integer,Integer>hm=new HashMap<Integer,Integer>();
		for(int i=0;i<len;i++)
		{
			int power=(int)Math.pow(arr[i],2);
			hm.put(arr[i],new Integer(power));
			
		}
		/*Set set=hm.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext()) {
			Map.Entry me=(Map.Entry)i.next();
			System.out.println(me.getKey()+ " : "+me.getValue());
		}*/
		return hm;
	}

}
