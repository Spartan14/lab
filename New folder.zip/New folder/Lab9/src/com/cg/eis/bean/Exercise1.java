package com.cg.eis.bean;
import java.util.*;
public class Exercise1 {  //lab 9_1
	public List getValues(HashMap hm,int c)
	{
		Set set=hm.entrySet();
		Iterator itr=set.iterator();
		int arr[]=new int[c];
		int i=0;
		//Sorting the values into an array
		while(itr.hasNext() && i!=c)
		{
			Map.Entry me=(Map.Entry) itr.next();
			arr[i]=(int) me.getValue();
			i++;
		}
		Arrays.sort(arr);
		System.out.println();
		System.out.println();
		
		List<Integer> hs=new ArrayList<Integer>();
		for(int j=0;j<arr.length;j++)
		{
			hs.add(arr[j]);
		}
		return hs;
	}
}
