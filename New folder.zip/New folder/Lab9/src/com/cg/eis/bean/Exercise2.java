package com.cg.eis.bean;
import java.util.*;
public class Exercise2 {  //lab 9_2
	
	public Map countCharacter(char arr1[])
	{
		int len = arr1.length;
		int count=0;
		Map<Character,Integer>m1=new HashMap<Character,Integer>();
		for(int i=0;i<len;i++)
		{
			count=0;
			char ch=arr1[i];
			for(int j=0;j<len;j++)
			{
				if(j<i && ch==arr1[j])
				{
					break;
				}
				if(arr1[j]==ch)
					count++;
			}
			if(count>0)
				m1.put(arr1[i],count);
				
		}
		return m1;
		
	}

}
