package com.cg.eis.bean;

import java.util.*;

public class Exercise6 {
	public void getDays(Date d1)
	{
		System.out.println("The given date is\t:\t"+d1);
		Date d2=new Date();
		
		System.out.println("The System Date is\t:\t"+d1);
		System.out.println("The difference between given date and system date is\t:\t");
		System.out.println(Math.abs(d1.getDate()-d2.getDate())+"Days-");
		System.out.println(Math.abs(d1.getMonth()-d2.getMonth())+"Months-");
		System.out.println(Math.abs(d1.getYear()-d2.getYear())+"Years-");
		
	}

}
