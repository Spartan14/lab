package com.cg.eis.bean;

public class Exercise5 {
	
	public boolean checkPositive(String str){
		
		boolean br=false;
		int len= str.length();
		System.out.println(len);
		for(int i=len-1;i>0;i--)
		{
			if(str.charAt(i-1)<str.charAt(i))
			br=true;
			else
				br=false;
		}
		return br;
	}

}
