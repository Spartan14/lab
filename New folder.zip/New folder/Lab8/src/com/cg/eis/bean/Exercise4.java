package com.cg.eis.bean;

import java.io.File;

public class Exercise4 {
	
	public void fileExists(String file) {
		File fr=new File(file);
		if(fr.exists())
		{
			System.out.println("File Exists.");
			System.out.println("Length of file\t:\t"+fr.length());
		}
		else
			System.out.println("File not Exists.");
		if(fr.canExecute())
			System.out.println("File can Execute.");
		if(fr.canRead())
			System.out.println("File can Read.");
		if(fr.canWrite())
			System.out.println("File can Write.");
		System.out.println("Given file Name is\t:\t"+file);
		String type[]=file.split("\\.");
		System.out.println("The file type is\t:\t"+type[1]);
	}

}
