package com.cg.eis.bean;

public class Exercise7 {
	
	public static boolean validateName(String Username) {
		
		int len=Username.indexOf("_job");
		boolean br=false;
		if(len >=8)
		{
			System.out.println("Valid Username");
			br=true;
		}
		else
		{
			System.out.println("Invalid Username");
			br=false;
		}
		return br;
	}

}
