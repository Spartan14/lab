package com.cg.eis.bean;

import java.util.StringTokenizer;

public class Exercise1 {
	public void getSumOfIntegers(String line)
	{
		StringTokenizer st=new StringTokenizer(line," ");
		int sum=0;
		while(st.hasMoreTokens())
		{
			int n=Integer.parseInt(st.nextToken());
			System.out.println("Integer\t"+n);
			sum=sum+n;
		}
		System.out.println("Sum of given integers is\t:\t"+sum);
	}

}
