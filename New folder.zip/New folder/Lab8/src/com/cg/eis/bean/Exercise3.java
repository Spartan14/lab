package com.cg.eis.bean;

import java.io.FileInputStream;
import java.io.IOException;

public class Exercise3 {
	
	public void getCount(String file) throws IOException{
		System.out.println("File Name\t:\t"+file+"\n");
		int lines=0,chars=0,words=0;
		int co=0;
		FileInputStream fis=new FileInputStream(file);
		while(fis.available()!=0)
		{
			co=fis.read();
			if(co!=10)
				chars++;
			if(co==32)
				words++;
			if(co==13)
			{
				lines++;
				words++;
			}		
			
		}
		System.out.println("No of Characters\t:\t"+chars);
		System.out.println("No of Words\t:\t"+(words+1));
		System.out.println("No of Lines\t:\t"+(lines+1));
	}

}
