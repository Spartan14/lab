package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Exercise5;

public class Demo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a String\t:\t");
		String str=sc.next();
		Exercise5 l1=new Exercise5();
		boolean b=l1.checkPositive(str);
		System.out.println(b);

	}

}
