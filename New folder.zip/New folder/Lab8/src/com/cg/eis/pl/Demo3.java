package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.eis.bean.Exercise3;

public class Demo3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Exercise3 l1=new Exercise3();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the FileName\t:\t");
		String file=br.readLine();
		l1.getCount(file);

	}

}
