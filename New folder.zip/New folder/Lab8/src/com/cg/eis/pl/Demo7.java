package com.cg.eis.pl;
import com.cg.eis.bean.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.cg.eis.bean.Exercise7;

public class Demo7 {  

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Username");
		String userName=br.readLine();
		System.out.println(Exercise7.validateName(userName));
	}

}
