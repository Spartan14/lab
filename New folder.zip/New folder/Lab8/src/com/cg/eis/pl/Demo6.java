package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.cg.eis.bean.Exercise6;

public class Demo6 {

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		int count=0;
		Exercise6 l2=new Exercise6();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter date in dd-MM-yyyy\t");
		String myDate=br.readLine();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		Date d1= sdf.parse(myDate);
		l2.getDays(d1);
				

	}

}
