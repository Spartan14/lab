package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.eis.bean.Exercise4;

public class Demo4 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		Exercise4 l1=new Exercise4();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the File Name\t:\t");
		String file=br.readLine();
		l1.fileExists(file);
		

	}

}
