package com.cg.eis.pl;

public class ServiceImpl {
	package com.recharge.service;



	import java.util.Collection;

	import java.util.regex.Matcher;

	import java.util.regex.Pattern;



	import com.recharge.bean.Recharge;

	import com.recharge.dao.IRechargeDao;

	import com.recharge.dao.RechargeDaoImpol;



	public class ServiceImpl implements IService {

	 IRechargeDao idao=null;

	 Matcher m =null;

	 private int generateTid() {

	 return (int)((Math.random())*10000);

	 }

	 @Override

	 public int mobRecharge(Recharge re) {

	 re.setrId(generateTid());

	 idao=new RechargeDaoImpol();

	 return idao.mobRecharge(re);

	 }



	 @Override

	 public boolean valName(String name) {

	 m=Pattern.compile("^[A-Z][a-z]{2,}").matcher(name);

	 if(m.find()){

	 return true;

	 }

	 return false;

	 }



	 @Override

	 public boolean valMob(String mob) {

	 m=Pattern.compile("[6-9][0-9]{9}").matcher(mob);

	 if(m.find()){

	  return true;

	 }

	 return false;

	 }



	 @Override

	 public boolean valrType(String rType) {

	 if(rType.equals("prepaid")||rType.equals("postpaid")){

	  return true;

	 }

	 return false;

	 }



	 @Override

	 public boolean valAmt(int amt) {

	 if(amt==199 || amt==399 || amt==499){

	  return true;

	 }

	 return false;

	 }

	 @Override

	 public Recharge viewByTId(int id) {

	 idao=new RechargeDaoImpol();

	 return (idao.viewByTId(id));

	 }

	 @Override

	 public Collection<Recharge> viewAllTransactions() {

	 idao=new RechargeDaoImpol();

	 return (idao.viewAllTransactions());

	 }

	 @Override

	 public int delete(int id1) {

	 idao=new RechargeDaoImpol();

	 return idao.delete(id1);

	 }



	}



}
