package com.cg.eis.pl;

public class DaoImpl {
	package com.recharge.dao;



	import java.util.Collection;

	import java.util.HashMap;

	import java.util.Map;



	import com.recharge.bean.Recharge;



	public class RechargeDaoImpol implements IRechargeDao {

	 static Map<Integer,Recharge> t=new HashMap<Integer,Recharge>();

	 @Override

	 public int mobRecharge(Recharge re) {

	 t.put(re.getrId(),re);

	 //	System.out.println(re.getrId());

	 return re.getrId();

	 }

	 @Override

	 public Recharge viewByTId(int id) {

	 Recharge re = t.get(id);

	 return re;

	 }

	 @Override

	 public Collection<Recharge> viewAllTransactions() {

	 Collection<Recharge> k=t.values();

	 return k;

	 }

	 @Override

	 public int delete(int id1) {

	 Recharge re=t.remove(id1);

	 System.out.println("Successfully Deleted!");

	 return 0;

	 }



	}



}
