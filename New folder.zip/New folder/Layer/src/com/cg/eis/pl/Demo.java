package com.cg.eis.pl;

public class Demo {

	public static void main(String[] args) {
		 package com.recharge.ui;



		 import java.util.Collection;

		 import java.util.Scanner;



		 import com.recharge.bean.Recharge;

		 import com.recharge.service.IService;

		 import com.recharge.service.ServiceImpl;







		 public class Ui {

		  static Scanner scan=new Scanner(System.in);

		  static IService iserv=null;

		  static int op;

		  public static void main(String[] args) {

		  while (op<6){

		   System.out.println("Enter any of the below options");

		   System.out.println("1.Recharge\n2.view all transactions\n3.view by Transaction ID\n4.Update\n5.Delete");

		   switch(scan.nextInt()){

		   case 1:

		   int kh=mobRecharge();

		   System.out.println("Recharge is Successful!");

		   System.out.println("Your transaction Id is : "+kh);

		   break;

		   case 2:

		   Collection<Recharge> rec=viewAllTransactions();

		   for(Recharge b:rec){

		    System.out.println(b.getName());

		    System.out.println(b.getMob());

		    System.out.println(b.getrType());

		    System.out.println(b.getAmt());

		    System.out.println(b.getrId());

		   }

		   break;

		   case 3:

		   Recharge r=viewByTId();

		   System.out.println(r.getName());

		   System.out.println(r.getMob());

		   System.out.println(r.getrType());

		   System.out.println(r.getAmt());

		   System.out.println(r.getrId());

		   break;

		   case 4:

		   break;

		   case 5:

		   delete();

		   break;

		   default :

		   System.out.println("Thank you for using the app");

		   }

		  }

		  }



		  private static void delete() {

		  System.out.println("Enter the Transaction ID to be deleted");

		  int id1=scan.nextInt();

		  iserv=new ServiceImpl();

		  iserv.delete(id1);





		  }



		  private static Collection<Recharge> viewAllTransactions() {

		  iserv=new ServiceImpl();

		  return (iserv.viewAllTransactions());

		  }



		  private static Recharge viewByTId() {

		  System.out.println("Enter the Trasaction ID");

		  int id=scan.nextInt();

		  iserv=new ServiceImpl();

		  return (iserv.viewByTId(id));





		  }

		  private static int mobRecharge() {

		  boolean flag;

		  System.out.println("Enter service provider name");

		  String name="";

		  do{

		   flag=iserv.valName(name=scan.next());

		   if(flag){

		   break;

		   }else{

		   System.out.println("Enter a Valid Service provider Name");

		   }

		  }while(!flag);

		  System.out.println("Enter mobile number");

		  String mob="";

		  do{

		   flag=iserv.valMob(mob=scan.next());

		   if(flag){

		   break;

		   }else{

		   System.out.println("Enter a valid mobile number");

		   }

		  }while(!flag);

		  System.out.println("Enter the recharge type");

		  String rType="";

		  do{

		   flag=iserv.valrType(rType=scan.next());

		   if(flag){

		   break;

		   }else{

		   System.out.println("Enter a correct recharge type");

		   }

		  }while(!flag);

		  System.out.println("Enter the recharge amount from the plans below : ");

		  System.out.println("1.Plan 199\n2.Plan 399\n3.499");

		  int amt;

		  do {

		   flag=iserv.valAmt(amt=scan.nextInt());

		   if(flag) {

		   break;

		   }else {

		   System.out.println("Enter the valid recharger amount");

		   }

		  }while(!flag);

		 // System.out.println("Add description");

		 // String descri=scan.next();

		  Recharge re=new Recharge(name,mob,rType,amt);

		  iserv=new ServiceImpl();

		  return iserv.mobRecharge(re);

		  }

		 }



	}

}
