package com.cg.eis.pl;

public class Dao {
	package com.recharge.dao;



	import java.util.Collection;



	import com.recharge.bean.Recharge;



	public interface IRechargeDao {

	 public int mobRecharge(Recharge re);

	  public Recharge viewByTId(int id);

	 public Collection<Recharge> viewAllTransactions();

	 public int delete(int id1);

	}



}
