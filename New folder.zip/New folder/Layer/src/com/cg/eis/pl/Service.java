package com.cg.eis.pl;

public class Service {
	package com.recharge.service;



	import java.util.Collection;



	import com.recharge.bean.Recharge;



	public interface IService {

	 public int mobRecharge(Recharge re);

	 public boolean valName(String name);

	 public boolean valMob(String mob);

	 public boolean valrType(String rType);

	 public boolean valAmt(int amt);

	 public Recharge viewByTId(int id);

	 public Collection<Recharge> viewAllTransactions();

	 public int delete(int id1);

	}



}
