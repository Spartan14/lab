package com.cg.ui;

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		System.out.println(a);
		
		Integer ob=a;
		System.out.println(ob);
		
		int b=ob;
		System.out.println(b);

	}

}
