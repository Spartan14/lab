package com.cg.ui;

public class Demo17 {
	
	public static void main(String[] args)
	{
		//String s="Don";
		//s=s+"Welcome";
		
		//StringBuffer ==> methods synchronized (thread safe).StringBuilder=>methods are not thread safe
		//both are having same methods
		//StringBuilder is faster than StringBuffer..StringBuilder is introduced jdk 1.5 onwards
		StringBuffer buffer=new StringBuffer("Hello");
		System.out.println("Buffer\t= "+buffer);//Hello
		System.out.println("length\t= "+buffer.length());//no of chars in a string //5
		System.out.println("Capacit\t= "+buffer.capacity());//capacity to store chars and it increases
		
		//appending and inserting into StringBuffer
		String s;
		int a=55;
		buffer=new StringBuffer(55);//capacity 55 chars//empty string in a StringBuffer
		s=buffer.append("a\t= ").append(a).append("!").toString();
		//========>a=55!
		System.out.println(s);//a=55!
		buffer=new StringBuffer("I java");
		buffer.insert(2,"like ");
		System.out.println(buffer);//like java
		buffer=buffer.reverse();
		System.out.println(buffer);

	}

}
