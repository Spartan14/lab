package com.cg.ui;
import java.io.*;
public class Demo8 {

	public static void main(String[] args)throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter line");
		String line=br.readLine();
		int wordCount=0;
		String s[]=line.split("");
		for(String word:s)
		{
			System.out.println(word);
			wordCount++;
		}
		System.out.println("Total word count is :"+wordCount);
		System.out.println("Enter date format dd-mm-yyyy");
		String date=br.readLine();
		String dd[]=date.split("-");
		for(String c:dd)
		{
			System.out.println(c);
			wordCount++;
		}
	}

}
