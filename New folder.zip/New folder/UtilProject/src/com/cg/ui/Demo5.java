package com.cg.ui;

public class Demo5 {

	public static void main(String[] args) {
		double a=215.54;
		System.out.println(a);
		Double ob1=new Double(a);//boxing
		System.out.println(ob1);
		
		Double ob2=new Double("3.14");
		System.out.println(ob2);//ob2 to string()
		Double ob3=Double.valueOf("100.60");//static method
		System.out.println(ob3);//ob3 to string()

	}

}
