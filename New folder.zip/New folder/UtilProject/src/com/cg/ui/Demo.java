package com.cg.ui;

public class Demo {
	public static void main(String[] args){
		long a=123232;//int promoted to long
		System.out.println("Long :"+a);
		int x=(int)a;//long typecasted to int
		System.out.println("int :"+x);
		double d1=312.55;
		System.out.println("Double :"+d1);
		int y=(int)d1;//double typecasted to int//fraction truncated
		System.out.println("int :"+y);
		byte z=(byte)d1;
		System.out.println("Byte :"+z);
		
		char c=66;
		System.out.println(c);
		int p=67;
		char p1=(char)p;
		System.out.println(p1);
	}

}
