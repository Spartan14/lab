package com.cg.ui;
import java.util.Arrays;
public class Demo6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b[]={65,66,67,68,69};
		String s1=new String(b);
		System.out.println(s1);
		byte buf[]=s1.getBytes();
		System.out.println(Arrays.toString(buf));
		
		char ch1[]={'C','a','p','2'};
		String s2=new String(ch1);
		System.out.println(s2);
		char ch2[]=s2.toCharArray();
		for(char ch:ch2)
				{
						System.out.println(ch);
					if(Character.isUpperCase(ch))
						System.out.println("Upper");
					if(Character.isLowerCase(ch))
							System.out.println("Lower");
					if(Character.isDigit(ch))
						System.out.println("Digit");
				}

	}

}
