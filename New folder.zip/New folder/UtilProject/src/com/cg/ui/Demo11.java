package com.cg.ui;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.text.ParseException;

public class Demo11 {

	public static void main(String[] args)throws IOException, ParseException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Date in dd-mm-yyyy hh:mm:ss");
		String mydate=br.readLine();
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy hh:mm:ss");
		Date d1=sdf.parse(mydate);
		System.out.println(d1);
		System.out.println(d1.getDate()+" "+d1.getMonth()+" "+d1.getYear());
		System.out.println(d1.getHours()+" "+d1.getMinutes()+" "+d1.getSeconds());
	}

}
