package com.cg.ui;
import java.util.regex.*;
public class Demo16 {

public static void main(String[] args){
	String input="Shop,Mop,Hopping,Chopping";
	Pattern pattern=Pattern.compile("op");
	Matcher matcher=pattern.matcher(input);
	
	while(matcher.find())
	{
		System.out.println(matcher.group()+"\t:\t"+matcher.start()+"\t:\t"+matcher.end());
	}
}
	
}
