package com.cg.ui;

import java.io.*;
import java.util.StringTokenizer;

public class Demo9 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter line");
		String line=br.readLine();
		StringTokenizer s=new StringTokenizer(line,"");
		while(s.hasMoreTokens())
		{
			String word=s.nextToken();
			System.out.println(word);
	}
	}
}
