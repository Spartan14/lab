package com.cg.ui;
import java.io.*;
import java.util.Currency;
import java.util.Locale;
public class Demo12 {
	public static void main(String[] args){
		Locale locale=Locale.getDefault();
		int amount=10000;
		Currency c=Currency.getInstance(locale);
		System.out.println("Using currency code\t: "+amount);
		System.out.println("Using currency symbol\t: "+amount+c.getSymbol());
		System.out.println("Using currency name\t: "+amount+" "+c.getDisplayName());
		
	}
}
