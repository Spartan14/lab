package com.cg.ui;
import static java.lang.Math.*;
import static java.lang.System.*;
//jdk 1.5 onwards static variables and methods can be imported
public class Demo18 {

	public static void main(String[] args) {
		//System.out.println(Math.PI);
		System.out.println(PI);
		//double res=Math.sqrt(4)
		double res=sqrt(4);
		System.out.println(res);
		out.println(res);
		
	}

}
