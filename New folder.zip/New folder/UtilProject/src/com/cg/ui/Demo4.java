package com.cg.ui;

public class Demo4 {

	public static void calculate(Double d)//boxing
	{	
		d=d*0.50;//unboxing
		System.out.println(d);
	}
	//wrapper class
	public static void main(String[] args)
	{
		//jdk 1.5 onwords
		double a=225.22;
		calculate(a);
	}

}
