package com.cg.ui;

public class Demo7 {

	public static void main(String[] args) {
		String s1=String.valueOf(100);//int is converted to String
		System.out.println(s1);
		
		String s2=String.valueOf(false);//boolean to String
		System.out.println(s2);
		
		String s3=String.valueOf(3.14);//double to String
		System.out.println(s3);
	}

}
