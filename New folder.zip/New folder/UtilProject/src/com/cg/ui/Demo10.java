package com.cg.ui;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Demo10 {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter line");
		String line=br.readLine();
		Scanner sc=new Scanner(line).useDelimiter(" ");
		StringTokenizer s=new StringTokenizer(line," ");
		while(sc.hasNext())
		{
			String a=sc.next();
			System.out.println(a);
		}
		sc.close();
	}

}
