package com.cg.ui;

public class Demo2 {
	//Wrapper class
	public static void main(String[] args)
	{
		//jdk 1.5 onwords
		int a=100;
		System.out.println(a);
		
		Integer ob=new Integer(a);
		System.out.println(ob);
		
		int b=ob.intValue();
		System.out.println(b);
	}

}
