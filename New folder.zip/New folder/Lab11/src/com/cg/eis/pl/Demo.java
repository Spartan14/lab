package com.cg.eis.pl;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.IOException;
import com.cg.eis.bean.Exercise1; //demo lab 10_1
public class Demo {
 public static void main(String[] args) throws InterruptedException {
 // TODO Auto-generated method stub
 Exercise1 ex=new Exercise1();
 try {
  ex.init("source.txt","target.txt");
  ex.copyContents();
 }
 catch(IOException e)
 {
  System.out.println("Caught in main\t:"+e.getMessage());
 }
  System.out.println("Inside : " + Thread.currentThread().getName());
     System.out.println("Creating Executor Service...");
     ExecutorService executorService = Executors.newSingleThreadExecutor();
     System.out.println("Creating a Runnable...");
     Runnable runnable = () -> {
       System.out.println("Inside : " + Thread.currentThread().getName());
     };

     System.out.println("Submit the task specified by the runnable to the executor service.");
     executorService.submit(runnable);
     executorService.submit(runnable);
     executorService.submit(runnable);
 }

}