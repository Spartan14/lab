package com.cg.bean;

public abstract class Shape {
	public abstract void area();

}
