package com.cg.ui;
import com.cg.bean.*;
public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s=new Rectangle(15,12);
		s.area();
	}

}
