package com.cg.bean;

public class Analyst extends Employee{
	private String project;
	public Analyst() {
		// TODO Auto-generated constructor stub
	}
	public Analyst(int eid,String ename,double salary,String project)
	{
		super(eid,ename,salary);
		this.project=project;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	@Override
	public void printDetails() {
		// TODO Auto-generated method stub
		super.printDetails();
		System.out.println("Emp project :"+project);
	}
	
	}
