package com.cg.ui;
import com.cg.bean.*;
public class Demo2 {
	public static void calculateBonus(Employee e)
	{
		double bonus=0.0;
		if(e instanceof Manager)
			bonus=e.getSalary()*0.50;
		else if(e instanceof Analyst)
			bonus=e.getSalary()*0.30;
		else
			bonus=e.getSalary()*0.20;
		System.out.println("Bonus is:"+bonus);
			
	}
	public static void main(String[] args) {
	
		Employee e=new Employee(100,"Balu",25000.00);
		e.printDetails();
		calculateBonus(e);
		
		e=new Manager(101,"Buddy",50000.00,"IT");
		e.printDetails();
		calculateBonus(e);
		
		e=new Analyst(102,"Venky",40000.00,"CR");
		e.printDetails();
		calculateBonus(e);
	}

}
