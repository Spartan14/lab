package com.cg.ui;
import com.cg.bean.*;
public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Manager(101,"Buddy",50000.00,"IT");
		e.printDetails();//Manager printDetails
		
		//string dept=e.getDepartment();//error
		
		Manager m=(Manager) e;//change e type to Manager type and store
		//object type casting //if u give wrong type then it give ClassCastException
		String dept=m.getDepartment();
		System.out.println(dept);
	}

}
