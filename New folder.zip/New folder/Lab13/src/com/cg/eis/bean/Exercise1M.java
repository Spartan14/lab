package com.cg.eis.bean;

public interface Exercise1M {
	public double power(double a,double b);

}
