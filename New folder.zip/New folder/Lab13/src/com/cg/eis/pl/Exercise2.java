package com.cg.eis.pl;

import java.util.Scanner;
import java.util.function.UnaryOperator;

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String ch=sc.next();
		int len=ch.length();
		UnaryOperator<String> uo=(ch1)->{
			char a[]=ch1.toCharArray();
			String b="";
			for(int i=0;i<len;i++)
			{
				b=b+a[i]+"";
			}
			return b;
		};
		System.out.println(uo.apply(ch));

	}

}
