package com.cg.eis.pl;

import java.util.Scanner;

interface Bigger{
	public void bigger(int a,int b);
}
public class Exercise4 {
	private int num1;
	private int num2;
	

	public int getNum1() {
		return num1;
	}


	public void setNum1(int num1) {
		this.num1 = num1;
	}


	public int getNum2() {
		return num2;
	}


	public void setNum2(int num2) {
		this.num2 = num2;
	}
	public void isBigger(int num1,int num2)
	{
		if(num1>num2)
			System.out.println("First number is greater");
		else
			System.out.println("Second number is greater");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the number");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		Exercise4 br=new Exercise4();
		Bigger x=br::isBigger;
		x.bigger(a, b);
		
		

	}

}
