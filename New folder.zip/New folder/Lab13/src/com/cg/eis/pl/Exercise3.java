package com.cg.eis.pl;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the username\t:\t");
		String uname=sc.next();
		System.out.println("Enter password\t:\t");
		String pass=sc.next();
		BiFunction<String,String,Boolean> check=(uname1,pass1)->uname1.equals("Capgemini") && pass1.equals("Openacc");
		boolean res=check.apply(uname,pass);
		if(res)
			System.out.println("Successfully opened account");
		else
			System.out.println("Sorry");

	}

}
