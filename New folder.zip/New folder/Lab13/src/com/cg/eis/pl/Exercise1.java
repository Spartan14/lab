package com.cg.eis.pl;

import com.cg.eis.bean.Exercise1M;

public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise1M em=(num1,num2)->{return Math.pow(num1,num2);};
		double result=em.power(4.0,2.0);
		System.out.println(result);

	}

}
