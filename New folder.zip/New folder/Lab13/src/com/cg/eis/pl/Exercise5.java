package com.cg.eis.pl;

import java.util.Scanner;

interface factorial
{
	public void fact(int num);
}
public class Exercise5 {
	
	public void fact(int num) {
		int f=1;
		if(num==0)
			System.out.println("Factorial :1");
		else
		{
			for(int i=1;i<=num;i++)
				f=f*i;
			System.out.println("Factorial is : "+f);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		Exercise5 e5=new Exercise5();
		factorial fa=e5::fact;
		fa.fact(num);

	}

}
