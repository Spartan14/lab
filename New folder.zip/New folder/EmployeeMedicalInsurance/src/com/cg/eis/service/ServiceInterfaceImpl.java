package com.cg.eis.service;
import java.util.Map;
import com.cg.eis.bean.Employee;
import com.cg.eis.dao.Dao;
import com.cg.eis.dao.DaoImpl;

public class ServiceInterfaceImpl implements ServiceInterface{
	Dao dao=new DaoImpl();

	@Override
	public Employee insuranceScheme(Employee e) {
		// TODO Auto-generated method stub
		String s="";
		if(e.getSalary()>=45000 && e.getDesignation().equals("Manager"))
		{
			s="Scheme A";
			System.out.println("Scheme of employee is "+s);
		}
		else if(e.getSalary()>=(22000) && e.getDesignation().equals("Programmer"))
		{
			s="Scheme B";
			System.out.println("Scheme of employee is "+s);
		}
		else if(e.getSalary()>=18000 && e.getDesignation().equals("system Associate"))
		{
			s="Scheme C";
			System.out.println("Scheme of employee is "+s);
		}
		e.setScheme(s);
		System.out.println(e.getScheme());
		return e;
	}

}
