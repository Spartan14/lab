package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface ServiceInterface {
	
	public Employee insuranceScheme(Employee e);
	
}
