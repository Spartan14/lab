package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.ServiceInterfaceImpl;

public class Demo {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter id\t:\t");
		String sid=br.readLine();
		int id=Integer.parseInt(sid);
		
		System.out.println("Enter Name\t:\t");;
		String name=br.readLine();
		
		System.out.println("Enter Designation\t:\t");
		String des=br.readLine();
		
		System.out.println("Enter Salary\t:\t");
		String esal=br.readLine();
		double salary=Double.parseDouble(esal);
		
		Employee e=new Employee(id,name,salary,des);
		new ServiceInterfaceImpl().insuranceScheme(e);
		System.out.println(e);

	}

}
