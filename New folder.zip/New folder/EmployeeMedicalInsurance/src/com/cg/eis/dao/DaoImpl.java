package com.cg.eis.dao;

import com.cg.eis.bean.Employee;

public class DaoImpl implements Dao {

	@Override
	public Employee insuranceScheme(double salary, String designation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getdetails(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
