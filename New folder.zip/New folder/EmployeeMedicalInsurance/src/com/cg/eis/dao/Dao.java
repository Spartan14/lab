package com.cg.eis.dao;

import com.cg.eis.bean.Employee;

public interface Dao {
	
	public Employee insuranceScheme(double salary,String designation);
	public Employee getdetails(int id);

}
