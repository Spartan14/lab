package com.cg.bean;

public enum Size {
	SMALL,MEDIUM,LARGE;

}
// All values are by default public final and static
//Size.SMALL => public final static Size SMALL=new Size();
