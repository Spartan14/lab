package com.cg.ui;
import com.cg.bean.*;
public class DrinkCoffeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coffee c1=new Coffee(Size.LARGE,200.00);
		System.out.println(c1);

	}

}
