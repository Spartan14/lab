package cg.ui;
import cg.bean.*;
public class Demo {

	public static void main(String[] args) {
		//Another class static members can be accessable
		//By class name no need to generate the object
		//As soon as Test class is loaded
		//static variables are initialized
		//static variable are called as class variables
		System.out.println(Test.count);
		Test.showCount();
		
		Test ob1=new Test();
		ob1.show();
		Test ob2=new Test();
		ob2.show();

	}

}
