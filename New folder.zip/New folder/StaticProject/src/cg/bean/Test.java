package cg.bean;

public class Test {
	int a;//normal variable//instance variable
	public static int count;
	static
	{
		count=50;
		System.out.println("Static block executed count :"+count);
	}
	public Test()
	{
		a++;
		count++;
	}
	
	//instance method or normal method
	public void show()
	{
		System.out.println("Non static variable a : "+a);
		System.out.println("Static variable count : "+count);
		
	}
	//static method
	public static void showCount()
	{
		//static block can access only static variable
		System.out.println("Count : "+count);
		//System.out.println(a);//error
		
	}

}
