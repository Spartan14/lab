package com.cg.bean;

//subclass extends common data(properties)functions(behaviour)
public class Manager extends Employee {
	//special data
	private String department;
	public Manager() {
		// TODO Auto-generated constructor stub
	}
	//parameterized constructor of subclass
	public Manager(int eid,String ename,double salary,String department)
	{
		super(eid,ename,salary);
		this.department=department;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
}
