package com.cg.ui;
import com.cg.bean.*;
public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee(100,"Balu",25000.00);
		e.printDetails();
		
		Manager m=new Manager(101,"Buddy",50000.00,"IT");
		m.printDetails();//sub class object calls super class method 
		
		Analyst a=new Analyst(102,"Venky",40000.00,"CR");
		a.printDetails();
	}

}
