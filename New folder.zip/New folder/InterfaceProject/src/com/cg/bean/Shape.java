package com.cg.bean;

public interface Shape {
	double PI=3.14;//public final static
	public void area();//public abstract
	//no method body
}
