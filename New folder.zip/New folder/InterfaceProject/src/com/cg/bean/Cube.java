package com.cg.bean;

public class Cube implements Shape,Shape3d {
private double side;

public Cube(double side) {
	super();
	this.side = side;
}

public double getSide() {
	return side;
}

public void setSide(double side) {
	this.side = side;
}

@Override
public void area() {
	// TODO Auto-generated method stub
	double ar=6*side*side;
	System.out.println("Area of the Cube :"+ar);
	
}

@Override
public void volume() {
	// TODO Auto-generated method stub
	double vol=side*side*side;
	System.out.println("Volume of the Cube :"+vol);
}


}
