package com.cg.bean;

public interface Shape3d {
	public void volume();
	
}
