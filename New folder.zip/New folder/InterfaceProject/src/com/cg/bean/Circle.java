package com.cg.bean;

public class Circle implements Shape{
	private double radious;
	public Circle(){
	// TODO Auto-generated method stub
		
	}
	public Circle(double radious){
	super();
	this.radious=radious;
	}

	public double getRadious() {
		return radious;
	}

	public void setRadious(double radious) {
		this.radious = radious;
	}
	public void area()
	{
		double ar=PI*radious*radious;
		System.out.println("Area of the circle is : "+ar);
		
	}
}
