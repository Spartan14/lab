package com.cg.ui;
import com.cg.bean.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Shape s=new Shape();//error//interface can not be instantiated
		Shape s=new Circle(15.25);
		s.area();//circle area
		
		Cube c=new Cube(7);
		c.area();
		c.volume();
		System.out.println("Polymorphism");
		s=c;
		s.area();
		Shape3d sd=c;
		sd.volume();
	}

}
