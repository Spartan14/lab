package com.cg.eis.pl;
import java.util.Scanner;
public class Demo2 {
	//exercise 2 Find the difference between the sum of the first n natural numbers and the square of the first n natural numbers.
		public static int calculateDifference(int n)
		{
			int sum1=0,sum2=0,fsum,m;
			for(int i=1;i<=n;i++)
			{
				sum1=sum1+(i*i);
				sum2=sum2+i;
			}
			fsum=sum2*sum2;
			m=Math.abs(sum1-fsum);
			return m;
		}
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter one number");
			int n=sc.nextInt();
			int res=calculateDifference(n);
			System.out.println("The difference is "+res);
		}
	



}
