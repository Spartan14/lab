package com.cg.eis.pl;
import java.util.Scanner;
class calculateSum
	{
		public static int calculateDifference(int n)
		{
			int sum1=0;
			for(int i=1;i<=n;i++)
			{
				if((i%3==0)||(i%5==0))
				{
				sum1=sum1+i;
				}
			}
			return sum1;
		}

		public static void main(String[] args)
		{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter one number");
				int n=sc.nextInt();
				int res=calculateDifference(n);
				System.out.println("The sum of the values that divide with 3 or 5 "+res);
		}
	}
