package com.cg.eis.pl;
import java.util.Scanner;
public class Demo4 {
	//exercise 4 program to check the entered number is a power of 2 or not
		public static boolean checkNumber(int n)
		{
			int r;
			while(n>1)
			{
				r=n%2;
				n=n/2;
				System.out.println(r);
				if(r==1)
				return false;
			}
			return true;
		}
		public static void main(String[] args)
		{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter one number");
				int n=sc.nextInt();
				boolean res=checkNumber(n);
				if(res)
					System.out.println("It is power of 2");
				else
					System.out.println("It is not power of 2");
	}

}
