package WalletService;

import WalletBean.WalletBean;
import Walletdao.UserException;

public interface WalletServiceInt {
	public String transferSer(WalletBean bankBeanFundTransObj)throws UserException;
	public float withdrawSer(WalletBean bankBeanWithdrawObj)throws UserException;
	public float depositSer(WalletBean bankBeanDepObj)throws UserException;
	public float showBalanceSer(WalletBean bankBeanShowBalObj)throws UserException;
	public void bankAccountCreate(WalletBean bankBeanObjCreateAccountObj)throws UserException;

}
